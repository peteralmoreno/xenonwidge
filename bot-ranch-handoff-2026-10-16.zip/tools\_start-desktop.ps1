$ErrorActionPreference = 'Stop'
try {
  $p = Start-Process -FilePath 'C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\desktop\botRanch.exe' -WorkingDirectory 'C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\desktop' -WindowStyle Hidden -PassThru
  Write-Output ('started pid ' + $p.Id)
} catch { Write-Output ('ERR: ' + $_.Exception.Message) }