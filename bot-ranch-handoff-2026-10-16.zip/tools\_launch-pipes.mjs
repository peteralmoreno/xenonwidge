import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// launch Piper + Petra terminals
for (const id of ['239bb5b6-2cdf-4df4-9efb-39b12c962128', '8c595c56-27f6-471b-aa04-3654d53fcde6']) {
  const r = await fetch(base + '/admin/action', { method: 'POST', headers: H, body: JSON.stringify({ id, action: 'new', confirmed: true }) });
  console.log('new:', r.status, (await r.text()).slice(0, 80));
}
await new Promise(res => setTimeout(res, 28000));
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st.profiles.filter(x => ['Piper', 'Petra'].includes(x.nickname))) {
  console.log(`${p.nickname}: state=${p.state} status=${p.status}`);
}