import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const t = st.tasks.find(x => ['pipe-catalog-probe'].includes(x.title));
if (t) {
  const a = (t.attempts || []).at(-1);
  console.log('pipe-catalog-probe:', t.status, a?.state, a?.profileId?.slice(0, 8));
  if (['dispatching','awaiting-runtime','claimed','running'].includes(a?.state)) {
    // stop Piper's current task to free everything
    const r = await fetch(base + '/admin/task/stop', { method: 'POST', headers: H, body: JSON.stringify({ id: a.profileId, confirmed: true, expectedAttemptId: a.id }) });
    console.log('stop:', r.status, (await r.text()).slice(0, 100));
    await new Promise(r => setTimeout(r, 8000));
  }
}
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
const t2 = st2.tasks.find(x => x.title === 'pipe-catalog-probe');
console.log('after stop:', t2?.status, (t2?.attempts || []).at(-1)?.state);