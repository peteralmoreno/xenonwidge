import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

test('setup offers sixteen named swatches, reserves used colors and omits obsolete login checks', async () => {
  const nodes = new Map();
  const make = () => ({value:'',children:[],dataset:{},style:{setProperty(){}},append(...children){this.children.push(...children);},replaceChildren(){this.children=[];},setAttribute(){},showModal(){this.open=true;},close(){this.open=false;},click(){return this.onclick();}});
  const get = id => {if(!nodes.has(id)) nodes.set(id,make());return nodes.get(id);};
  const profiles = [{id:'one',nickname:'Brick',folder:'D:/project',color:0,active:true,status:'closed',label:'Closed'}];
  const context = {document:{getElementById:get,createElement:make,querySelectorAll:()=>[]},URLSearchParams,location:{hash:'#admin=test',pathname:'/'},history:{replaceState(){}},sessionStorage:{getItem(){},setItem(){}},AbortSignal,setInterval(){},fetch:async url=>({ok:true,json:async()=>url.endsWith('/checks')?{checks:[{name:'Model login',ok:null,detail:'old companion'},{name:'Node',ok:true,detail:'Ready'}]}:{profiles,sleepSeconds:60,widgetConnected:false}})};
  vm.runInNewContext(fs.readFileSync(new URL('../setup/app.js',import.meta.url),'utf8'),context);
  await new Promise(resolve=>setImmediate(resolve));
  get('add').click();
  const choices=get('color-options').children;
  assert.equal(choices.length,16);
  assert.equal(get('color').value,'1');
  assert.equal(choices[0].children[0].disabled,true);
  assert.equal(choices[1].children[0].checked,true);
  assert.equal(choices[11].children[2].textContent,'Red');
  assert.equal(new Set(choices.map(choice=>choice.children[1].style.backgroundColor)).size,16);
  choices[11].children[0].onchange();
  assert.equal(get('color').value,'11');
  assert.equal(get('check-list').children.length,1);
  assert.match(get('check-list').children[0].textContent,/Node/);
  get('cards').children[0].children[0].children[1].click();
  assert.equal(get('color').value,'0');
  assert.equal(get('color-options').children[0].children[0].disabled,false);
});
