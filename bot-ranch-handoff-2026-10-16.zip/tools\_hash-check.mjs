import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('state keys:', Object.keys(st).join(', '));
console.log('widgetControlHash in state:', st.widgetControlHash ? st.widgetControlHash.slice(0, 16) + '...' : 'undefined');
// ranch.json has the hash; state doesn't expose it — confirm by reading ranch.json via hash file
const rj = JSON.parse(fs.readFileSync('C:/Users/petermo/AppData/Local/OmpBot/ranch.json', 'utf8'));
console.log('ranch.json hash:', rj.widgetControlHash.slice(0, 16) + '...');
const newKey = fs.readFileSync('C:/bot-home/control-key.txt', 'utf8').trim();
const crypto = await import('node:crypto');
console.log('new key matches ranch hash:', crypto.createHash('sha256').update(newKey).digest('hex') === rj.widgetControlHash);