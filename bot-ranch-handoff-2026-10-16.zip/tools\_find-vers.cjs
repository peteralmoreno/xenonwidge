const fs = require('fs');
const root = 'C:/source/xenonwidge';
(function walk(d, depth) {
  if (depth > 3) return;
  for (const n of fs.readdirSync(d)) {
    const f = d + '/' + n;
    const s = fs.statSync(f);
    if (s.isDirectory()) { if (!n.startsWith('.') && !['node_modules', 'artifacts'].includes(n)) walk(f, depth + 1); }
    else if (/\.(json|mjs|js|ps1|md)$/i.test(n)) {
      const c = fs.readFileSync(f, 'latin1');
      if (c.includes('0.17.1')) console.log('VERS:', f.slice(root.length + 1));
    }
  }
})(root, 0);