import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// Repoint jack to his own room (already C:\bot-home\rooms\jack per ranch.json — this is just an idempotent nudge)
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const j = st.profiles.find(p => p.nickname === 'jack');
console.log('jack folder:', j.folder);
if (j.folder.toLowerCase() !== 'c:\\bot-home\\rooms\\jack'.toLowerCase()) {
  const body = { id: j.id, nickname: j.nickname, color: j.color, folder: 'C:/bot-home/rooms/jack', role: j.role, preferredModel: j.preferredModel, readOnly: j.readOnly, autoPickup: j.autoPickup, contextPolicy: j.contextPolicy, personality: j.personality, design: j.design, instructionsPath: j.instructionsPath, expectedRevision: j.revision };
  const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
  console.log('repoint jack:', r.status, (await r.text()).slice(0, 100));
} else console.log('jack already in own room');
// Now kill jack's wrong tree (mintty 36396 + runner 40052 + omp under it) so a fresh launch runs in the right room
const { execSync } = await import('node:child_process');
try {
  const out = execSync('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match \'bbc091f4\' -or $_.ProcessId -eq 36396 -or $_.ProcessId -eq 38048 -or $_.ProcessId -eq 40052 } | Select-Object -ExpandProperty ProcessId"', { encoding: 'utf8' });
  const ids = out.trim().split(/\s+/).filter(Boolean);
  for (const id of ids) { try { execSync('taskkill /T /F /PID ' + id, { stdio: 'ignore' }); } catch {} }
  console.log('killed jack wrong tree pids:', ids.join(','));
} catch (e) { console.log('kill err', e.message); }
await new Promise(r => setTimeout(r, 5000));
// relaunch jack in own room
const r2 = await fetch(base + '/admin/action', { method: 'POST', headers: H, body: JSON.stringify({ id: j.id, action: 'new', confirmed: true }) });
console.log('jack new:', r2.status, (await r2.text()).slice(0, 80));
await new Promise(r => setTimeout(r, 25000));
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
const j2 = st2.profiles.find(p => p.nickname === 'jack');
console.log('jack now:', j2.state, j2.status);