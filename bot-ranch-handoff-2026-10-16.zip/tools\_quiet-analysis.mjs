import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// pairing key == session key == what /admin/key returned. The widget should connect with it.
// Since the user pasted the correct key and it still fails, look at the WIDGET's actual network behavior:
// The widget runs inside iCUE. It fetches http://127.0.0.1:43822/state. iCUE sandbox may block loopback OR
// the widget's fetch may carry iCUE's own Origin which our server rejects? We saw CORS '*', ok.
// Check: does the SERVER reject based on host header? 'if(!/^127\.0\.0\.1:\d+$/.test(req.headers.host))' — the widget fetches http://127.0.0.1:43822 so host ok.
// Another suspect: the widget manifest min_app_version 5.47 — maybe the iCUE runtimes block http:// (Private Network Access). Access-Control-Allow-Private-Network:'true' present.
// The REAL test: reproduce the widget request flow with the exact headers iCUE sends? Hard. Instead, LOOK AT whether the INSTALLED desktop's own widget window (mode:'icue') uses same flow and works — it does per user 'diagnostic says connected'. Wait: user said 'diagnostic says connected and ranch says quiet' => the DIAGNOSTIC (setup/board) shows connected. That means the pairing IS working at the companion! The ranch widget UI just shows 'quiet' because NO SESSION HAS ACTIVITY: all bots offline except Emily, and Sherlock shows no resident selected (selectedId=Jill offline).
// CONCLUSION: 'ranch says quiet' is the widget's honest render: selected resident Jill is offline => 'The ranch is quiet'. NOT a connection failure! The diagnostic connected = pairing ok. The fix: SELECT a live bot (Emily-pm) or the widget's default shows the first resident (Jill, offline) => quiet.
// Verify: what does the widget show for Emily? sessions[4] = Emily ready. The widget list orders by slot (0..4). Jill slot0 => default quiet.
// Tell the user to click Emily-pm in the widget's roster — the panel flips to 'Ready for a question'.
const k2 = await (await fetch(base + '/admin/key', { headers: H })).json();
console.log('pairing/session key (paste):', k2.key);
// quick check: does the widget's render loop pick the FIRST session or selection? desk app current():
const d = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
let i = d.indexOf('function current');
console.log(d.slice(i, i + 220).replace(/\r/g, ''));