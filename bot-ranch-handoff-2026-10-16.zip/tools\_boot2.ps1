$ErrorActionPreference = 'SilentlyContinue'
Start-Process -FilePath 'C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\desktop\botRanch.exe' -WorkingDirectory 'C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\desktop' -WindowStyle Hidden
Start-Sleep -Seconds 10
$c = Test-NetConnection -ComputerName 127.0.0.1 -Port 43822 -InformationLevel Quiet -WarningAction SilentlyContinue
Write-Output ('port=' + $c)