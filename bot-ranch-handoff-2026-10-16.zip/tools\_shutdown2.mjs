import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// retry to clear the interrupted attempt (blocked -> todo)
let st = await (await fetch(base + '/admin/state', { headers: H })).json();
let t = st.tasks.find(x => x.title === 'pipe-probe');
console.log('pipe-probe:', t.status, 'last=', (t.attempts || []).at(-1)?.state);
if (t.status === 'blocked') {
  const r = await fetch(base + '/admin/task/retry', { method: 'POST', headers: H, body: JSON.stringify({ id: t.id, expectedRevision: t.revision }) });
  console.log('retry:', r.status, (await r.text()).slice(0, 80));
}
// shutdown companion
const r2 = await fetch(base + '/admin/shutdown', { method: 'POST', headers: H });
console.log('shutdown:', r2.status, (await r2.text()).slice(0, 100));