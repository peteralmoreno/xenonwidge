using System;
using System.IO;
using System.IO.Compression;

class ZipRelease {
    static int Main(string[] args) {
        if (args.Length != 2) { Console.Error.WriteLine("usage: ZipRelease <source-dir> <dest-zip>"); return 2; }
        string source = args[0], destination = args[1];
        if (!Directory.Exists(source)) { Console.Error.WriteLine("source not found: " + source); return 2; }
        string destDir = Path.GetDirectoryName(Path.GetFullPath(destination));
        if (!string.IsNullOrEmpty(destDir)) Directory.CreateDirectory(destDir);
        if (File.Exists(destination)) File.Delete(destination);
        try {
            ZipFile.CreateFromDirectory(source, destination, CompressionLevel.Optimal, false);
            return 0;
        } catch (Exception e) {
            Console.Error.WriteLine(e.Message);
            try { if (File.Exists(destination)) File.Delete(destination); } catch { }
            return 1;
        }
    }
}
