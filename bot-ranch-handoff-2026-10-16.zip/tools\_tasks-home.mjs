import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const t of st.tasks) {
  const body = { id: t.id, title: t.title, instructions: t.instructions, acceptanceCriteria: t.acceptanceCriteria, reasoningRequest: t.reasoningRequest || 'auto', humanReview: t.humanReview || false, releasedForPickup: t.releasedForPickup, expectedRevision: t.revision, stickyMode: t.stickyMode, projectFolder: t.projectFolder };
  // keep everything, only change projectFolder if it points at old home
  if (body.projectFolder.toLowerCase().includes('omprancherbot')) body.projectFolder = 'C:/bot-home';
  const r = await fetch(base + '/admin/task', { method: 'POST', headers: H, body: JSON.stringify(body) });
  console.log(`task ${t.title}: ${r.status} ${(await r.text()).slice(0, 100)}`);
}
// hmm - conditional: check what projectFolder they actually have now
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const t of st2.tasks) console.log(`task ${t.title} projectFolder=${t.projectFolder}`);