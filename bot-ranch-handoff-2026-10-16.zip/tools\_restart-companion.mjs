import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// First stop jack's current pipe-probe pickup so it doesn't burn a model call
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const t = st.tasks.find(x => x.title === 'pipe-probe');
const a = (t.attempts || []).at(-1);
console.log('pipe-probe attempt:', a?.state, 'profile', a?.profileId);
if (a && ['dispatching', 'awaiting-runtime', 'claimed', 'running'].includes(a.state)) {
  const r = await fetch(base + '/admin/task/stop', { method: 'POST', headers: H, body: JSON.stringify({ id: '1ba726a3-c4bc-421d-b35f-b5c0bb73696e', confirmed: true, expectedAttemptId: a.id }) });
  console.log('stop jack:', r.status, (await r.text()).slice(0, 120));
}
// shutdown companion (desktop restarts it)
const r2 = await fetch(base + '/admin/shutdown', { method: 'POST', headers: H });
console.log('shutdown:', r2.status, (await r2.text()).slice(0, 100));