const fs = require('fs');
const f = 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/renderer.js';
let c = fs.readFileSync(f, 'latin1');
// xc = swatch color array (the one mapped into buttons with PT[c] label)
const OLD = 'var xc=["#e58d77","#68bbc3","#ddb55c","#a396ca","#e78fb3","#e8a05b","#a8c966","#65b58e","#729edb","#8585d5","#bbc5cb","#cf7070","#e4dcad","#66d9ce","#d976ed","#a78362"]';
const NEW = OLD.replace(/\]$/, ',"#ff2d2d","#ff4dd8","#2ec4ff","#7cff3f"]');
const OLDQ = 'var xc=["#e58d77","#68bbc3","#ddb55c","#a396ca","#e78fb3","#e8a05b","#a8c966","#65b58e","#729edb","#8585d5","#bbc5cb","#cf7070","#e4dcad","#66d9ce","#d976ed","#a78362"]';
if (c.includes(OLD)) { fs.writeFileSync(f, c.replace(OLD, NEW), 'latin1'); console.log('renderer xc patched'); }
else if (c.includes(OLDQ)) { fs.writeFileSync(f, c.replace(OLDQ, NEW), 'latin1'); console.log('renderer xc patched (q)'); }
else console.log('renderer xc anchor missing');
// verify xc count
const v = fs.readFileSync(f, 'latin1');
const mc = v.match(/var xc=\[([^\]]*)\]/);
console.log('xc len:', mc ? mc[1].split('","').length : 'none');