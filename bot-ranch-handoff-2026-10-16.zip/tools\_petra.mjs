import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// second pipe bot — distinct name, color 1, different folder so both can run concurrently
const sister = {
  nickname: 'Petra', color: 1, folder: 'C:/source/runbooks', role: 'pipe',
  preferredModel: 'auto', readOnly: false, autoPickup: true, contextPolicy: 'per-task',
  personality: 'curious', design: 'classic', instructionsPath: ''
};
const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(sister) });
console.log('Petra:', r.status, (await r.text()).slice(0, 200));