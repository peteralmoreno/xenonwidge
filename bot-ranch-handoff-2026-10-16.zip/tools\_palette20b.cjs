const fs = require('fs');
const f = 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/board.js';
let c = fs.readFileSync(f, 'latin1');
const ORIG = "['#e58d77','#68bbc3','#ddb55c','#a396ca','#e78fb3','#e8a05b','#a8c966','#65b58e','#729edb','#8585d5','#bbc5cb','#cf7070','#e4dcad','#66d9ce','#d976ed','#a78362']";
if (c.includes(ORIG)) {
  fs.writeFileSync(f, c.replace(ORIG, ORIG.replace(/\]$/, ",'#ff2d2d','#ff4dd8','#2ec4ff','#7cff3f']")), 'latin1');
  console.log('patched board.js');
} else console.log('still missing');
// verify all copies now carry 20
for (const f2 of ['C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/ui/sprites.js','C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/app.js','C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/board.js','C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js','C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/renderer.js']) {
  const c2 = fs.readFileSync(f2, 'latin1');
  console.log(f2, c2.includes('#ff2d2d') ? '20-colors' : (c2.includes('#ff2d2d') ? 'ok' : 'STILL 16'));
}