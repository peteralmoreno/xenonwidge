const fs = require('fs');
const files = ['C:/source/xenonwidge/sources/omp-bot/sprites.js', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/ui/sprites.js'];
// Keep ${ink} literal for the BROWSER: escape the template by using a tagged literal in the patch source.
const pmDesign = [
  "  if(design==='pm'){",
  "   // Little fedora: brim + crown, and dark sunglasses over the eyes.",
  "   const hat='<g class=\"pm-hat\"><rect x=\"16\" y=\"6\" width=\"32\" height=\"4\" fill=\"' + ink + '\"/><rect x=\"21\" y=\"9\" width=\"22\" height=\"7\" fill=\"' + ink + '\"/><rect x=\"21\" y=\"9\" width=\"22\" height=\"2\" fill=\"#456255\"/></g>';",
  "   const shades='<g class=\"pm-shades\"><rect x=\"22\" y=\"22\" width=\"20\" height=\"6\" fill=\"#101820\"/><rect x=\"24\" y=\"24\" width=\"3\" height=\"2\" fill=\"#eaf2f5\"/><rect x=\"36\" y=\"24\" width=\"3\" height=\"2\" fill=\"#eaf2f5\"/><path d=\"M42 24h4v3h-4z\" fill=\"' + ink + '\"/><path d=\"M19 24h3v3h-3z\" fill=\"' + ink + '\"/></g>';",
  "   const pm = '<g class=\"pm\">' + hat + shades + '</g>';",
  "   result = result.replace(/(<g class=\"robot\">)/, '$1' + pm);",
  "  }"
].join('\n');
for (const file of files) {
  if (!fs.existsSync(file)) { console.log('skip missing', file); continue; }
  let c = fs.readFileSync(file, 'latin1');
  if (c.includes("design==='pm'")) { console.log('already has pm in', file); continue; }
  const anchor = "  if(design==='pipeline'){";
  if (c.includes(anchor)) {
    c = c.replace(anchor, pmDesign + "\n" + anchor);
    console.log('added pm design to', file);
  } else console.log('anchor missing in', file);
  fs.writeFileSync(file, c, 'latin1');
}