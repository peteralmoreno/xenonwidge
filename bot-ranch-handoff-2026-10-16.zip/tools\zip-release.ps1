param([Parameter(Mandatory=$true)][string]$Source, [Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference = 'Stop'
# CLM-safe: Add-Type / [System.IO.Compression] are blocked in Constrained Language Mode.
# Use the built-in Compress-Archive cmdlet with retries for transient AV file locks.
$attempts = 0
while ($true) {
    try {
        Compress-Archive -Path (Join-Path $Source '*') -DestinationPath $Destination -CompressionLevel Optimal -Force -ErrorAction Stop
        break
    } catch {
        $attempts++
        if ($attempts -ge 8) { throw }
        Start-Sleep -Milliseconds 750
    }
}