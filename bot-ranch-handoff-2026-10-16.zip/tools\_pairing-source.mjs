import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// Good: /state accepts the session key with foreign Origin (CORS ok). The widget key SHOULD work now if it's the session key.
// BUT the widget may have cached the OLD key in localStorage after my first key paste attempt (the control key — rejected, so connected=false). Since paste uses localStorage instantly, a WRONG stored key persists. Need to clear it: widget 'Connect' -> paste session key AGAIN -> should overwrite.
// Alternative: the widget may be the OLD build before patched desk CSP? Compare the INSTALLED desk/app.js base/request vs RELEASE desk app.
const inst = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
// check the widget manifest pairing: does manifest.json set a pairing key?
const mj = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/manifest.json', 'latin1');
console.log('desk manifest:', mj.slice(0, 400).replace(/\n/g, ' '));
// what does the launcher pass to the widget? check main.cjs / desktop for widget spawn
const mc = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/main.cjs', 'latin1');
for (const m of mc.matchAll(/.{40}(pair|key|widget|icue).{50}/gi)) console.log('desktop:', m[0].replace(/\n/g, ' ').slice(0, 150));