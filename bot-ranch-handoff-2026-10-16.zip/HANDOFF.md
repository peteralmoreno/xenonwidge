# Bot Ranch — Consolidated Handoff

Snapshot for the original creator. This bundles every local patch, the patched source,
tests, findings and design docs from `C:/source/xenonwidge` so new features can be built
on top of the current machine-specific state instead of the stock 0.17.1 baseline.

## What this is

A working fork of stock **botRanch 0.17.1**, heavily patched for this machine (Windows 11
Enterprise, WDAC/VBS Constrained Language Mode, iCUE/XENEON EDGE, OMP extension runtime).

- **`PATCHLOG.md`** — the authoritative list of all 14 local patches (read first).
- **`VERSIONING.md`** — repo layout, version bumps, and the 0.18 release recipe.
- **`sources/`** — every project's patched source (the editable tree).
- **`tools/`** — release builder (`build.cjs`) plus `_clm-helpers/` compiled helpers
  (`Terminal-Focus.exe`, `Terminal-Close.exe`, `ZipRelease.exe`) patched for CLM.
- **`tests/`, `specs/`, `docs/`** — runtime/injected tests, board+behavior findings, guides.
- **`README.md`, `package.json`, `playwright.config.cjs`, `.gitignore`** — root project files.

## Verified sync state (2026-10-16)

All 14 PATCHLOG entries applied to **Source**, **Installed**
(`%LOCALAPPDATA%\Programs\botRanch\versions\0.17.1`), and **Release** (`artifacts/`).
Spot-checked release-vs-source on every patched file (`sprites.js`, `app.js`, `manager.mjs`,
`bot-library.mjs`, `terminal-runner.mjs`, `setup/*`, `desk/*`) — **all identical, no drift.**

## Excluded from this zip (not part of handoff)

- `node_modules/` (479MB) — run `npm ci`.
- `artifacts/releases/` — rebuildable via `npm run build` / `node tools/build.cjs ranch build`.
  The stock baseline zip inside is redownloadable from the existing release page.
- `DLs/` — unpacked stock 0.17.1 baseline (520MB), used only for diffing; download fresh.
- All gitignored local state/credentials: `.env*`, `**/pairing-key.txt`, `**/admin-key.txt`,
  `**/ranch.json`, `**/bot-home/`, `**/sessions/`, `**/terminals/`, `**/handovers/`,
  `.scratch/`, `.superpowers/`. None of these belong to the creator.
- `.git/` — `git init` was run at this root; the initial commit records this exact snapshot.

## Recipe for the creator

1. Read `PATCHLOG.md`, then `VERSIONING.md`.
2. `npm ci` (needs Node 22.12+, .NET 9 SDK for companion tests).
3. `npm test` — unit, browser, and companion tests (Playwright chromium via
   `npx playwright install chromium` first).
4. `node tools/build.cjs ranch build` — rebuild patched release artifacts.
5. To ship 0.18: bump `sources/omp-bot/manifest.json` + `sources/omp-bot-desktop/package.json`
   `"version"`, rebuild, sanity-check per `VERSIONING.md`.

## Machine-specific behavior — do NOT "fix" back

- Companion port `127.0.0.1:43822`; admin key from `%LOCALAPPDATA%\OmpBot\admin-key.txt`.
- Bot home `C:\bot-home`; per-bot rooms under `C:\bot-home\rooms\<nick>`.
- Smoke-runner unblock is `taskkill /T /F` (PATCHLOG #1) — the terminal runner deliberately
  kills the OMP tree to consume the `.next.json` handoff; do not restore graceful shutdown.
- Focus is **no-steal by default** (PATCHLOG #2); PowerShell is CLM-safe with compiled
  native helpers (PATCHLOG #13).