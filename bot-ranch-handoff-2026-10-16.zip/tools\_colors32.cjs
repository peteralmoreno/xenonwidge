const fs = require('fs');

const EXTRA = [
  ['tangerine', '#ff6b00', '#ffb877'],
  ['sun', '#ffd400', '#fff080'],
  ['spring', '#00e676', '#8af7c9'],
  ['teal', '#00b8a9', '#86e8dd'],
  ['azure', '#0a7dff', '#9cc8ff'],
  ['royal', '#5e35ff', '#b3a1ff'],
  ['grape', '#9b30ff', '#d2a3ff'],
  ['fuchsia', '#ff0088', '#ff99d0'],
  ['watermelon', '#ff4f6d', '#ffb0bc'],
  ['lavender', '#b388ff', '#e0d0ff'],
  ['pearl', '#ffffff', '#f0f0f0'],
  ['jet', '#151515', '#4d4d4d'],
];
const HEX = EXTRA.map(e => `'${e[1]}'`).join(',');
const HEXDQ = EXTRA.map(e => `"${e[1]}"`).join(',');
const NAMES = EXTRA.map(e => `'${e[0].charAt(0).toUpperCase()}${e[0].slice(1)}'`).join(',');
const NAMESDQ = EXTRA.map(e => `"${e[0].charAt(0).toUpperCase()}${e[0].slice(1)}"`).join(',');
const TRIPLETS = EXTRA.map(e => `['${e[0]}','${e[1]}','${e[2]}']`).join(',');

const log = [];
// 1. sprites.js (source + installed ui)
for (const f of [
  'C:/source/xenonwidge/sources/omp-bot/sprites.js',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/ui/sprites.js',
]) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes("'tangerine'")) { log.push('skip sprites ' + f); continue; }
  const anchor = "['neon','#7cff3f','#d4ffb8']];";
  if (!c.includes(anchor)) { log.push('MISS anchor sprites ' + f); continue; }
  fs.writeFileSync(f, c.replace(anchor, "['neon','#7cff3f','#d4ffb8']," + TRIPLETS + '];'), 'latin1');
  log.push('sprites patched ' + f);
}
// 2. manager.mjs range 19 -> 31
for (const f of [
  'C:/source/xenonwidge/sources/omp-bot-companion/manager.mjs',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/manager.mjs',
]) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes('input.color>31')) { log.push('skip manager ' + f); continue; }
  if (!c.includes('input.color>19')) { log.push('MISS manager anchor ' + f); continue; }
  fs.writeFileSync(f, c.replace('input.color>19', 'input.color>31'), 'latin1');
  log.push('manager range patched ' + f);
}
// 3. bot-library.mjs range
for (const f of [
  'C:/source/xenonwidge/sources/omp-bot-companion/bot-library.mjs',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/bot-library.mjs',
]) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes('p.color>31')) { log.push('skip bot-library ' + f); continue; }
  if (!c.includes('p.color>19')) { log.push('MISS library anchor ' + f); continue; }
  fs.writeFileSync(f, c.replace('p.color>19', 'p.color>31'), 'latin1');
  log.push('bot-library range patched ' + f);
}
// 4. setup/app.js colors + colorNames (single-quoted hex)
for (const f of [
  'C:/source/xenonwidge/sources/omp-bot-companion/setup/app.js',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/app.js',
]) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes("'#ff6b00'")) { log.push('skip setup/app ' + f); continue; }
  let changed = false;
  if (c.includes(",'#7cff3f'],")) { c = c.replace(",'#7cff3f'],", ",'#7cff3f'," + HEX + '],'); changed = true; }
  if (c.includes("'Neon']")) { c = c.replace("'Neon']", "'Neon'," + NAMES + ']'); changed = true; }
  if (changed) { fs.writeFileSync(f, c, 'latin1'); log.push('setup/app patched ' + f); }
  else log.push('MISS setup/app anchors ' + f);
}
// 5. setup/board.js botColors
for (const f of [
  'C:/source/xenonwidge/sources/omp-bot-companion/setup/board.js',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/board.js',
]) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes("'#ff6b00'")) { log.push('skip setup/board ' + f); continue; }
  if (!c.includes(",'#7cff3f']")) { log.push('MISS setup/board anchor ' + f); continue; }
  fs.writeFileSync(f, c.replace(",'#7cff3f']", ",'#7cff3f'," + HEX + ']'), 'latin1');
  log.push('setup/board patched ' + f);
}
// 6. desk/app.js (source ranch-desk + installed)
for (const f of [
  'C:/source/xenonwidge/sources/ranch-desk/app.js',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js',
]) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes("'#ff6b00'")) { log.push('skip desk ' + f); continue; }
  const anchor = "'#7cff3f']";
  if (!c.includes(anchor)) { log.push('MISS desk anchor ' + f); continue; }
  fs.writeFileSync(f, c.replace(anchor, "'#7cff3f'," + HEX + ']'), 'latin1');
  log.push('desk patched ' + f);
}
// 7. desktop renderer.js (xc + PT)
const r = 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/renderer.js';
let rc = fs.readFileSync(r, 'latin1');
if (rc.includes('"#ff6b00"')) log.push('skip renderer (already)');
else {
  let changed = false;
  if (rc.includes('"#7cff3f"]')) { rc = rc.replace('"#7cff3f"]', '"#7cff3f",' + HEXDQ + ']'); changed = true; }
  if (rc.includes('"Neon"]')) { rc = rc.replace('"Neon"]', '"Neon",' + NAMESDQ + ']'); changed = true; }
  if (changed) { fs.writeFileSync(r, rc, 'latin1'); log.push('renderer patched'); }
  else log.push('MISS renderer anchors');
}
console.log(log.join('\n'));