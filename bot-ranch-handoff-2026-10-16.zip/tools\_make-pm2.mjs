import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// Rename role name to Project Manager
const r1 = await fetch(base + '/admin/role', { method: 'POST', headers: H, body: JSON.stringify({ id: 'pm', name: 'Project Manager', model: 'auto', instructions: fs.readFileSync('C:/bot-home/roles/pm/agent.md', 'latin1') }) });
console.log('role rename:', r1.status, (await r1.text()).slice(0, 80));
// create bot with design pm — but the server was restarted with OLD manager (no pm design). Check live roles list includes pm?
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('roles:', st.roles.map(r => r.id).join(','));
// Use classic for now (pm design requires companion restart to accept). The sprite is patched in source + installed ui; restart loads it.
const used = new Set(st.profiles.map(p => p.color));
let free = 2; while (used.has(free)) free++;
fs.mkdirSync('C:/bot-home/rooms/pm', { recursive: true });
const body = { nickname: 'PM', color: free, folder: 'C:/bot-home/rooms/pm', role: 'pm', preferredModel: 'auto', readOnly: false, autoPickup: false, contextPolicy: 'per-task', personality: 'calm', design: 'classic' };
const r2 = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
console.log('profile PM:', r2.status, (await r2.text()).slice(0, 160));
// then flip design to pm once the companion restarts with the patched manager
if (r2.ok) {
  const p = (await r2.json());
  const body2 = { ...p, expectedRevision: p.revision, design: 'pm' };
  const r3 = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body2) });
  console.log('design->pm:', r3.status, (await r3.text()).slice(0, 120));
}