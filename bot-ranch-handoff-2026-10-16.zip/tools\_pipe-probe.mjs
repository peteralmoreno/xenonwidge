import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const t = st.tasks.find(x => x.title === '1');
console.log('task1:', t.status, 'pipeOnly=', t.pipeOnly);
// create a NEW pipe-only test task (priority queue, not released yet)
const body = {
  title: 'pipe-probe', projectFolder: 'C:/bot-home/rooms/piper', instructions: 'Trigger and babysit a Catalog_Info run for nomore-workspace. Report the workflow id and status. Do not release until told.',
  acceptanceCriteria: '', reasoningRequest: 'auto', humanReview: true,
  releasedForPickup: false, expectedRevision: st.taskRevision, stickyMode: 'inherit',
  pipeOnly: true, assignedProfileId: null
};
const r = await fetch(base + '/admin/task', { method: 'POST', headers: H, body: JSON.stringify(body) });
console.log('create pipe-probe:', r.status, (await r.text()).slice(0, 150));