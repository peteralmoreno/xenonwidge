const fs = require('fs');
const f = 'C:/source/xenonwidge/PATCHLOG.md';
let c = fs.readFileSync(f, 'utf8');
const line = '- pm role display name → "Product Manager" (user requirement).\n';
if (c.includes(line)) {
  c = c.replace(line, '');
  fs.writeFileSync(f, c, 'utf8');
  console.log('removed pm-name line');
} else {
  // arrow may differ; find by prefix
  const i = c.indexOf('pm role display name');
  console.log('found idx', i);
  if (i > 0) {
    const start = c.lastIndexOf('\n', i);
    const end = c.indexOf('\n', i);
    const l = c.slice(start + 1, end);
    console.log('actual line:', JSON.stringify(l));
    c = c.slice(0, start + 1) + c.slice(end + 1);
    fs.writeFileSync(f, c, 'utf8');
    console.log('removed by idx');
  }
}
// also fix the Status NOTE in section 10
const oldStatus = '| Status | Done; NOTE: role display name still says "Project Manager" — user wants "Product Manager" (pending fix) |';
if (c.includes(oldStatus)) {
  c = c.replace(oldStatus, '| Status | Done |');
  fs.writeFileSync(f, c, 'utf8');
  console.log('status fixed');
} else console.log('status line not found (or already fixed)');