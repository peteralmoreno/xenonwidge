import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('roles:', st.roles.map(r => r.id).join(','));
// 1. accept the pipe-catalog-probe review task -> done
const probe = st.tasks.find(x => x.title === 'pipe-catalog-probe');
if (probe && probe.status === 'review') {
  const r = await fetch(base + '/admin/task/review', { method: 'POST', headers: H, body: JSON.stringify({ id: probe.id, expectedRevision: probe.revision, action: 'accept' }) });
  console.log('accept probe:', r.status, (await r.text()).slice(0, 80));
} else console.log('probe status:', probe?.status);
// 2. archive it (tidy)
if (probe && probe.status === 'done') {
  const r = await fetch(base + '/admin/task/archive', { method: 'POST', headers: H, body: JSON.stringify({ id: probe.id, expectedRevision: probe.revision }) });
  console.log('archive probe:', r.status, (await r.text()).slice(0, 80));
}
// 3. set PM design -> pm (manager now accepts 'pm')
const pm = st.profiles.find(p => p.nickname === 'PM');
if (pm) {
  const body = { id: pm.id, nickname: pm.nickname, color: pm.color, folder: pm.folder, role: pm.role, preferredModel: pm.preferredModel, readOnly: pm.readOnly, autoPickup: pm.autoPickup, contextPolicy: pm.contextPolicy, personality: pm.personality, design: 'pm', instructionsPath: pm.instructionsPath, expectedRevision: pm.revision };
  const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
  console.log('PM design->pm:', r.status, (await r.text()).slice(0, 140));
}