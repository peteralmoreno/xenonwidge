using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

// Bring a mintty window forward WITHOUT stealing keyboard focus (default).
// Uses non-activating window APIs only: ShowWindowAsync (SW_SHOWNOACTIVATE),
// SetWindowPos (SWP_NOACTIVATE) and BringWindowToTop via HWND_NOTOPMOST.
// If the caller passes a second argument "steal" the classic activating
// sequence is used instead (restore + SetForegroundWindow).
class TerminalFocus3 {
    [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
    [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] static extern bool PostMessageW(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool SetFocus(IntPtr hWnd);
    [DllImport("user32.dll")] static extern bool SetActiveWindow(IntPtr hWnd);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr hWnd, uint cmd);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);

    const uint WM_SYSCOMMAND = 0x0112;
    static readonly IntPtr SC_RESTORE = new IntPtr(0xF120);
    const uint SWP_NOSIZE = 0x0001;
    const uint SWP_NOMOVE = 0x0002;
    const uint SWP_NOACTIVATE = 0x0010;
    const uint SPI_SETFOREGROUNDLOCKTIMEOUT = 0x2001;
    const int SW_SHOWNOACTIVATE = 4;
    const int SW_RESTORE = 9;

    static IntPtr FindMainByPid(int pid) {
        Process proc = null;
        try { proc = Process.GetProcessById(pid); } catch { }
        if (proc != null) {
            IntPtr main = proc.MainWindowHandle;
            if (main != IntPtr.Zero && IsWindowVisible(main)) return main;
        }
        IntPtr h = GetWindow(IntPtr.Zero, 0);
        while (h != IntPtr.Zero) {
            uint owner;
            GetWindowThreadProcessId(h, out owner);
            if (owner == (uint)pid && IsWindowVisible(h)) return h;
            h = GetWindow(h, 2);
        }
        return IntPtr.Zero;
    }

    static int Main(string[] args) {
        int pid;
        if (args.Length < 1 || !int.TryParse(args[0], out pid)) return 2;
        bool steal = args.Length > 1 && args[1].Equals("steal", StringComparison.OrdinalIgnoreCase);
        IntPtr h = FindMainByPid(pid);
        if (h == IntPtr.Zero) return 1;
        if (IsIconic(h)) { ShowWindowAsync(h, SW_RESTORE); PostMessageW(h, WM_SYSCOMMAND, SC_RESTORE, IntPtr.Zero); }
        if (steal) {
            SystemParametersInfo(SPI_SETFOREGROUNDLOCKTIMEOUT, 0, IntPtr.Zero, 0);
            uint owner;
            GetWindowThreadProcessId(h, out owner);
            uint current = GetCurrentThreadId();
            try { AttachThreadInput(current, owner, true); } catch { }
            ShowWindowAsync(h, 5);
            BringWindowToTop(h);
            SetActiveWindow(h);
            SetFocus(h);
            SetForegroundWindow(h);
            SetWindowPos(h, (IntPtr)(-1), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
            SetWindowPos(h, (IntPtr)(-2), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
            try { AttachThreadInput(current, owner, false); } catch { }
            if (GetForegroundWindow() == h) return 0;
            System.Threading.Thread.Sleep(50);
            SetForegroundWindow(h);
            return GetForegroundWindow() == h ? 0 : 1;
        }
        // Default: raise without stealing focus. SW_SHOWNOACTIVATE + HWND_NOTOPMOST
        // brings the window visible/top without activating it.
        if (ShowWindowAsync(h, SW_SHOWNOACTIVATE)) { }
        SetWindowPos(h, (IntPtr)(-1), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE); // HWND_TOPMOST
        SetWindowPos(h, (IntPtr)(-2), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE); // HWND_NOTOPMOST
        // If minimized restored above; Confirm it is visible/top at least.
        return 0;
    }
}