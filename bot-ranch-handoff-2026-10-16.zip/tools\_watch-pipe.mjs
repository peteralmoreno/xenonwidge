import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key };
const TID = fs.readFileSync('C:/source/xenonwidge/tools/_probe-id.txt', 'utf8').trim();
const tdir = path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'terminals');
for (let i = 0; i < 20; i++) {
  await new Promise(r => setTimeout(r, 5000));
  const st = await (await fetch(base + '/admin/state', { headers: H })).json();
  const t = st.tasks.find(x => x.id === TID);
  const a = (t.attempts || []).at(-1);
  const owner = a ? st.profiles.find(p => p.id === a.profileId)?.nickname : '-';
  const runners = fs.readdirSync(tdir).filter(f => f.endsWith('.next.json'));
  console.log(`t+${(i + 1) * 5}s ${t.title}: ${t.status} owner=${owner} last=${a?.state} next=[${runners}]`);
  if (['doing', 'review', 'done', 'blocked'].includes(t.status)) { console.log('TERMINAL'); break; }
}