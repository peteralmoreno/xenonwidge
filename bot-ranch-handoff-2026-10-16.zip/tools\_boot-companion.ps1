$ErrorActionPreference = 'SilentlyContinue'
$exe = 'C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\desktop\botRanch.exe'
if (-not (Test-Path $exe)) { Write-Output 'desktop exe missing'; exit 1 }
$p = Start-Process -FilePath $exe -WorkingDirectory (Split-Path $exe) -WindowStyle Hidden -PassThru
Write-Output ('started pid ' + $p.Id)
Start-Sleep -Seconds 8
$c = Test-NetConnection -ComputerName 127.0.0.1 -Port 43822 -InformationLevel Quiet -WarningAction SilentlyContinue
Write-Output ('port=' + $c)