const fs = require('fs');
const files = [
  'C:/source/xenonwidge/sources/omp-bot-companion/manager.mjs',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/manager.mjs',
  'C:/source/xenonwidge/sources/omp-bot-companion/bot-library.mjs',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/bot-library.mjs',
];
// 1. manager.mjs design validation accepts 'pm'
for (const f of files.slice(0, 2)) {
  let c = fs.readFileSync(f, 'latin1');
  const a1 = "if(!['classic','pipeline'].includes(design))throw Error('Choose Classic or Pipeline design.')";
  if (c.includes(a1)) { c = c.replace(a1, "if(!['classic','pipeline','pm'].includes(design))throw Error('Choose Classic, Pipeline, or PM design.')"); console.log('manager design patched', f); }
  else console.log('manager design anchor missing', f);
  fs.writeFileSync(f, c, 'latin1');
}
// 2. bot-library constructor also validates design
for (const f of files.slice(2, 4)) {
  let c = fs.readFileSync(f, 'latin1');
  const a2 = "design:['classic','pipeline'].includes(p.design)?p.design:'classic'";
  if (c.includes(a2)) { c = c.replace(a2, "design:['classic','pipeline','pm'].includes(p.design)?p.design:'classic'"); console.log('library design patched', f); }
  else console.log('library design anchor missing', f);
  fs.writeFileSync(f, c, 'latin1');
}
// 3. desk app.js design select only offers classic/pipeline — extend to pm
const deskFiles = ['C:/source/xenonwidge/sources/omp-bot/app.js', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/ui/app.js'];
for (const f of deskFiles) {
  if (!fs.existsSync(f)) { console.log('skip', f); continue; }
  let c = fs.readFileSync(f, 'latin1');
  const a3 = "$('profile-design').value=profile.design==='pipeline'?'pipeline':'classic';";
  if (c.includes(a3) && !c.includes("'pm'")) {
    c = c.replace(a3, "$('profile-design').value=['pipeline','pm'].includes(profile.design)?profile.design:'classic';");
    console.log('desk design select patched', f);
  } else console.log('desk anchor missing or patched', f);
  fs.writeFileSync(f, c, 'latin1');
}
// 4. design preview helper in app.js uses $('profile-design').value directly — OK since we set it above.
console.log('done');