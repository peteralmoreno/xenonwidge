using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

class TerminalClose {
    [DllImport("user32.dll")] static extern bool PostMessageW(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr hWnd, uint cmd);

    const uint WM_CLOSE = 0x0010;

    static IntPtr FindByPid(int pid) {
        Process proc = null;
        try { proc = Process.GetProcessById(pid); } catch { }
        if (proc != null) {
            IntPtr main = proc.MainWindowHandle;
            if (main != IntPtr.Zero && IsWindow(main)) return main;
        }
        IntPtr h = GetWindow(IntPtr.Zero, 0);
        while (h != IntPtr.Zero) {
            uint owner;
            GetWindowThreadProcessId(h, out owner);
            if (owner == (uint)pid && IsWindow(h)) return h;
            h = GetWindow(h, 2);
        }
        return IntPtr.Zero;
    }

    static int Main(string[] args) {
        int pid;
        if (args.Length < 1 || !int.TryParse(args[0], out pid)) return 2;
        IntPtr h = FindByPid(pid);
        if (h == IntPtr.Zero) return 1;
        PostMessageW(h, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
        Process p = null;
        try { p = Process.GetProcessById(pid); } catch { return 1; }
        try { p.WaitForExit(5000); } catch { }
        if (p.HasExited) return 0;
        return 1;
    }
}
