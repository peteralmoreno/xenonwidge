import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };

// rename Petra -> Penelope first (nickname change), then rooms script will repoint her
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const petra = st.profiles.find(p => p.nickname === 'Petra');
if (petra) {
  const body = { id: petra.id, nickname: 'Penelope', color: petra.color, folder: petra.folder, role: petra.role, preferredModel: petra.preferredModel, readOnly: petra.readOnly, autoPickup: petra.autoPickup, contextPolicy: petra.contextPolicy, personality: petra.personality, design: petra.design, instructionsPath: petra.instructionsPath, expectedRevision: petra.revision };
  const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
  console.log('rename Petra->Penelope:', r.status, (await r.text()).slice(0, 120));
} else console.log('Petra not found, ids:', st.profiles.map(p=>p.nickname).join(','));
