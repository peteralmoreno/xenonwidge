import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const pm = st.roles.find(r => r.id === 'pm');
console.log('role pm:', JSON.stringify({ id: pm?.id, name: pm?.name }));
// if it says Project Manager or Program Manager, fix to Product Manager
if (pm && pm.name !== 'Product Manager') {
  const r = await fetch(base + '/admin/role', { method: 'POST', headers: H, body: JSON.stringify({ id: 'pm', name: 'Product Manager', expectedRevision: pm.revision }) });
  console.log('rename role:', r.status, (await r.text()).slice(0, 120));
  const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
  console.log('after:', st2.roles.find(r => r.id === 'pm')?.name);
} else console.log('already Product Manager or missing');