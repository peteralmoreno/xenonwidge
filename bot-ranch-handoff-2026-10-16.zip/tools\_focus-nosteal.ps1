$ErrorActionPreference = 'SilentlyContinue'
$live = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'Bot Ranch - Piper' } | Select-Object -First 1
if (-not $live) { Write-Output 'no live piper'; exit 1 }
$proc = Get-Process -Id $live.ProcessId -ErrorAction SilentlyContinue
$started = $proc.StartTime.ToUniversalTime().Ticks.ToString()
$r = & powershell.exe -NoProfile -NonInteractive -File "C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\Focus-Terminal.ps1" -TerminalPid $live.ProcessId -Started $started 2>&1
Write-Output ("ps1 result=[" + $r + "] code=" + $LASTEXITCODE)