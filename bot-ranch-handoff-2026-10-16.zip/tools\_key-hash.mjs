import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const savedHash = st.widgetControlHash;
// The new key we provisioned — verify it matches the saved hash
const newKey = fs.readFileSync('C:/bot-home/control-key.txt', 'utf8').trim();
const h = crypto.createHash('sha256').update(newKey).digest('hex');
console.log('new key hash matches saved hash:', h === savedHash);
// the widget's localStorage key lives in the widget's own storage, not ranch.json. Check what key the widget would have used: the INSTALLED UI has a pairing flow where the key is pasted into the Connect dialog. The widget fails with 401 => its stored key does not match the hash.
// The ranch.json hash = key provisioned by the LAUNCHER when opening the widget. If we changed it, the widget's stored key is stale.
// Solution: tell the user to open the widget's Connect dialog and paste the NEW key from C:/bot-home/control-key.txt, OR re-open the widget so the launcher re-syncs the key.
console.log('widgetControlHash:', savedHash.slice(0,16) + '...');
console.log('to fix: open widget > Connect > paste key from C:/bot-home/control-key.txt');