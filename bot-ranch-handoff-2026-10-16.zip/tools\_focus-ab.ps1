$ErrorActionPreference = 'SilentlyContinue'
$live = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'Bot Ranch - Piper' } | Select-Object -First 1
if (-not $live) { Write-Output 'no piper'; exit 1 }
$proc = Get-Process -Id $live.ProcessId -ErrorAction SilentlyContinue
$started = $proc.StartTime.ToUniversalTime().Ticks.ToString()
$focusExe = 'C:\source\xenonwidge\tools\_clm-helpers\Terminal-Focus.exe'
Write-Output ("pid=" + $live.ProcessId)
# old vs new exe
$old = 'C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\Terminal-Focus.exe'
Write-Output ("old: " + (& $old $live.ProcessId))
Write-Output ("new: " + (& $focusExe $live.ProcessId))
# direct HWND variant via Terminal-Close approach is close-based; skip. Report codes
Write-Output ("new exitcode=" + $LASTEXITCODE)