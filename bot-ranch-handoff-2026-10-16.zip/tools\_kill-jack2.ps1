$ErrorActionPreference = 'SilentlyContinue'
# Target the exact jack tree: runner 40052 and its omp children + jack root mintty 36396
$ids = @(36396, 37140, 38048, 40052, 36612, 37484)
# also walk children of each
$all = Get-CimInstance Win32_Process
$queue = @($ids)
$seen = @{}
while ($queue.Count) {
  $cur = $queue[0]; $queue = @($queue[1..($queue.Count - 1)])
  if ($seen.ContainsKey($cur)) { continue }
  $seen[$cur] = $true
  foreach ($c in $all) { if ($c.ParentProcessId -eq $cur) { $queue += $c.ProcessId } }
}
$ids = @($seen.Keys)
foreach ($id in $ids) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 1200
Write-Output ('killed: ' + ($ids -join ','))
# verify no Bot Ranch - jack remains
$left = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'Bot Ranch - jack' }
Write-Output ('jack remaining: ' + ($left | ForEach-Object { $_.ProcessId }) -join ',')