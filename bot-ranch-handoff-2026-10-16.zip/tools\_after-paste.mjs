import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// 1. did the widget connect after the paste? check flag
const s = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('widgetConnected:', s.widgetConnected, '| controlEnabled:', s.controlEnabled);
console.log('updates count:', (s.updates || []).length);
// 2. what key does the widget use for /control? the desk widget may use the SESSION key (server 'key') not control-key.
// server: /admin/key returns the *companion session* key used by desk widget 'connect' flow? Check desk app connect:
const d = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
console.log('--- desk connect flow ---');
for (const m of d.matchAll(/.{0,80}(connect|pair|fetch\(|/control/).{0,60}/g)) console.log(m[0].replace(/\n/g, ' ').slice(0, 150));