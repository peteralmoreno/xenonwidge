import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const em = st.profiles.find(p => p.nickname === 'Emily-pm');
if (!em) { console.log('Emily-pm missing'); process.exit(1); }
const body = { id: em.id, nickname: em.nickname, color: 16, folder: em.folder, role: em.role, preferredModel: em.preferredModel, readOnly: em.readOnly, autoPickup: em.autoPickup, contextPolicy: em.contextPolicy, personality: em.personality, design: 'pm', instructionsPath: em.instructionsPath, expectedRevision: em.revision };
const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
console.log('Emily color=16 design=pm:', r.status, (await r.text()).slice(0, 150));