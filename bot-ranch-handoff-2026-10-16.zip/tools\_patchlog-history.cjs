const fs = require('fs');
const f = 'C:/source/xenonwidge/PATCHLOG.md';
let c = fs.readFileSync(f, 'utf8');
// 1. Ensure section 10 title says Product Manager and add instruction note about the rename (History)
if (!c.includes('(Product Manager)')) {
  c = c.replace('## 10. pm role (Product Manager) + pipe role', '## 10. pm role (Product Manager) + pipe role');
}
// append a History line documenting the rename (name fixed from Program Manager -> Project Manager -> Product Manager on 2026-10-14)
const history = `
Role display-name history: created as "Program Manager" (2026-10-14), renamed "Project
Manager" mid-session, then corrected to **"Product Manager"** per user requirement
(2026-10-14, role ` + '`pm`' + ` id kept, revision bumped).`;
if (!c.includes('Role display-name history')) {
  const anchor = '## 11. Pipe workspace convention (user rule)';
  if (c.includes(anchor)) c = c.replace(anchor, history + '\n\n' + anchor);
}
fs.writeFileSync(f, c, 'utf8');
console.log('patchlog pm history added');