const fs = require('fs');
// ---- 1. Expand palette: replace the existing 'red' entry with a brighter set? No — ADD new colors 16..19 (red-hot, magenta, sky, neon-green) and keep 0-15 stable. But slots are 0-5 and colors are free-form ints; the manager validates 0-15. Raise to 0-19.
const targets = [
  'C:/source/xenonwidge/sources/omp-bot/sprites.js',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/ui/sprites.js',
];
const extra = `,['hotred','#ff2d2d','#ff9b9b'],['magenta','#ff4dd8','#ffb8ef'],['sky','#2ec4ff','#b8e9ff'],['neon','#7cff3f','#d4ffb8']`;
for (const f of targets) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes("'hotred'")) { console.log('already has hotred in', f); continue; }
  // insert extras before the closing ]
  const anchor = "['copper','#a78362','#dec09d']];";
  if (c.includes(anchor)) {
    c = c.replace(anchor, "['copper','#a78362','#dec09d']" + extra + "];");
    console.log('expanded palette in', f);
  } else console.log('palette anchor missing in', f);
  fs.writeFileSync(f, c, 'latin1');
}
// ---- 2. manager color validation 0-19
for (const f of ['C:/source/xenonwidge/sources/omp-bot-companion/manager.mjs', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/manager.mjs']) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes('input.color>19')) { console.log('manager already 19 in', f); continue; }
  const a1 = "!Number.isInteger(input.color)||input.color<0||input.color>15)throw Error('Choose one of the sixteen colors.')";
  if (c.includes(a1)) {
    c = c.replace(a1, "!Number.isInteger(input.color)||input.color<0||input.color>19)throw Error('Choose a supported color.')");
    console.log('manager color range patched', f);
  } else console.log('manager color anchor missing', f);
  fs.writeFileSync(f, c, 'latin1');
}
// ---- 3. bot-library profile validation 0-15 -> 0-19
for (const f of ['C:/source/xenonwidge/sources/omp-bot-companion/bot-library.mjs', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/bot-library.mjs']) {
  let c = fs.readFileSync(f, 'latin1');
  const a2 = "!Number.isInteger(p.color)||p.color<0||p.color>15)throw Error('Invalid portable bot profile: '+file)";
  if (c.includes(a2)) {
    c = c.replace(a2, "!Number.isInteger(p.color)||p.color<0||p.color>19)throw Error('Invalid portable bot profile: '+file)");
    console.log('library color range patched', f);
  } else console.log('library color anchor missing in', f);
  fs.writeFileSync(f, c, 'latin1');
}
console.log('done');