const fs = require('fs');
// scan for any palette arrays (hex or names) with 14-25 entries but NOT 32 in all js under sources + installed
const roots = ['C:/source/xenonwidge/sources', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1'];
const reHexArr = /(?:colors?|botColors|swatches?)\s*=\s*(\[[^\]]{30,}?\])/gi;
for (const root of roots) {
  (function walk(d) {
    for (const n of fs.readdirSync(d)) {
      const f = d + '/' + n;
      const s = fs.statSync(f);
      if (s.isDirectory()) { if (!n.startsWith('.') && n !== 'node_modules') walk(f); }
      else if (/\.(js|mjs)$/.test(n)) {
        const c = fs.readFileSync(f, 'latin1');
        for (const m of c.matchAll(reHexArr)) {
          const hex = m[1].match(/#[0-9a-fA-F]{6}/g) || [];
          if (hex.length >= 10 && hex.length !== 32) console.log('HEX-ARR', hex.length, ':', f);
        }
        const mNames = c.match(/(?:colorNames|names|pt)\s*=\s*(\[[^\]]{30,}?\])/gi);
        if (mNames) for (const mm of mNames) {
          const names = (mm.match(/['\"][A-Z][a-z]+(?: [A-Z][a-z]+)?['\"]/g) || []);
          if (names.length >= 10 && names.length !== 32) console.log('NAME-ARR', names.length, ':', f);
        }
      }
    }
  })(root);
}
console.log('scan done');