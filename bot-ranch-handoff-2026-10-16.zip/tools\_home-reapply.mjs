import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// live state now
let st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('homeFolder live:', st.homeFolder);
console.log('profiles:', st.profiles.map(p => `${p.nickname} folder=${p.folder} state=${p.state}`).join(' | '));
// re-apply setHome
const r = await fetch(base + '/admin/settings', { method: 'POST', headers: H, body: JSON.stringify({ homeFolder: 'C:/bot-home' }) });
console.log('re-apply setHome:', r.status, (await r.text()).slice(0, 120));
st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('homeFolder after:', st.homeFolder);
console.log('roles:', st.roles.map(r => r.id).join(','));
