const fs = require('fs');
const root = 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1';
(function walk(d, depth) {
  if (depth > 4) return;
  for (const n of fs.readdirSync(d)) {
    const f = d + '/' + n;
    const s = fs.statSync(f);
    if (s.isDirectory()) { if (!n.startsWith('.') && n !== 'node_modules') walk(f, depth + 1); }
    else if (/widget/i.test(f)) console.log('WIDGET:', f);
  }
})(root, 0);