import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const pm = st.profiles.find(p => p.nickname === 'PM');
if (!pm) { console.log('PM not found; profiles:', st.profiles.map(p=>p.nickname).join(',')); process.exit(1); }
// rename + move room to emily-pm
import fs2 from 'node:fs';
fs2.mkdirSync('C:/bot-home/rooms/emily-pm', { recursive: true });
const body = { id: pm.id, nickname: 'Emily-pm', color: pm.color, folder: 'C:/bot-home/rooms/emily-pm', role: pm.role, preferredModel: pm.preferredModel, readOnly: pm.readOnly, autoPickup: pm.autoPickup, contextPolicy: pm.contextPolicy, personality: pm.personality, design: pm.design, instructionsPath: pm.instructionsPath, expectedRevision: pm.revision };
const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
console.log('rename->Emily-pm:', r.status, (await r.text()).slice(0, 160));
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st2.profiles) console.log(`${p.nickname}: design=${p.design} folder=${p.folder}`);