import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const pm = st.roles.find(r => r.id === 'pm');
if (pm) {
  // clone full role payload, change only the name
  const body = { ...pm, name: 'Product Manager' };
  delete body.revision; delete body.updatedAt; delete body.lastUsedAt;
  body.expectedRevision = pm.revision;
  const r = await fetch(base + '/admin/role', { method: 'POST', headers: H, body: JSON.stringify(body) });
  console.log('rename:', r.status, (await r.text()).slice(0, 160));
  const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
  console.log('after:', st2.roles.find(r => r.id === 'pm')?.name);
} else console.log('role pm missing');