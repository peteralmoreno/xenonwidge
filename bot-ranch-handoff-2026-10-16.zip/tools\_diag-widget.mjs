import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// 1. companion up?
try {
  const h = await (await fetch(base + '/admin/health', { headers: H, signal: AbortSignal.timeout(3000) })).json();
  console.log('health:', JSON.stringify(h));
} catch (e) { console.log('health ERR', e.message); }
// 2. widget control-key / state?
try {
  const st = await (await fetch(base + '/admin/state', { headers: H })).json();
  console.log('widgetControlHash:', st.widgetControlHash);
  console.log('profiles:', st.profiles.map(p => p.nickname + ':' + p.state).join(','));
} catch (e) { console.log('state ERR', e.message); }
// 3. is the desk served? GET /desk/ with key?
try {
  const r = await fetch(base + '/desk/', { headers: H, signal: AbortSignal.timeout(3000) });
  console.log('/desk/ ->', r.status, r.headers.get('content-type'), (await r.text()).slice(0, 80).replace(/\n/g, ' '));
} catch (e) { console.log('/desk/ ERR', e.message); }
// 4. runtime/control? widget uses ?key= or bearer? check server.mjs socket route
try {
  const r = await fetch(base + '/control/state', { headers: H, signal: AbortSignal.timeout(3000) });
  console.log('/control/state ->', r.status, (await r.text()).slice(0, 120).replace(/\n/g, ' '));
} catch (e) { console.log('/control/state ERR', e.message); }