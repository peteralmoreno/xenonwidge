import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// Read current pipe role agent.md from source of truth, extend with workspace convention.
const ROLE_MD = 'C:/bot-home/rooms/pipe/agent.md';
let md = fs.existsSync(ROLE_MD) ? fs.readFileSync(ROLE_MD, 'latin1') : '';
const convention = `

## Workspace convention (IMPORTANT)
- Your project workspace (where you READ AND WRITE files during a task) is your OWN room folder (C:/bot-home/<you>). The task's projectFolder is your home unless the task explicitly says it edits runbooks/repos.
- Runbooks (C:/source/runbooks/), skills (C:/Users/petermo/.omp/agent/skills/api-cli/), and the product source of truth (C:/trend/shipwright/ + C:/trend/shipwright-platform/) are READ-ONLY REFERENCES. Read them for context; do NOT work inside them unless the task says so.
- Save observations, scratch notes, handoffs, and details for the task in .scratch/ under YOUR home room (e.g. C:/bot-home/rooms/piper/.scratch/). Keep it tidy: one file per task.
`;
if (!md.includes('## Workspace convention (IMPORTANT)')) {
  md += convention;
  fs.writeFileSync('C:/bot-home/roles/pipe/agent.md', md, 'latin1');
  console.log('pipe role agent.md updated');
} else console.log('already has convention');
// verify state
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('roles:', st.roles.map(r => r.id).join(','));
for (const p of st.profiles) console.log(`${p.nickname}: role=${p.role} design=${p.design} folder=${p.folder} auto=${p.autoPickup} state=${p.state}/${p.status}`);