$r = & powershell.exe -NoProfile -NonInteractive -File "C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\Focus-Terminal.ps1" -TerminalPid 1 -Started 638000000000000000 2>&1
Write-Output ("result=[" + $r + "] code=" + $LASTEXITCODE)
# live piper pid test
$live = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'Bot Ranch - Piper' } | Select-Object -First 1
if ($live) {
  $proc = Get-Process -Id $live.ProcessId -ErrorAction SilentlyContinue
  $started = $proc.StartTime.ToUniversalTime().Ticks.ToString()
  Write-Output ("live pid=" + $live.ProcessId + " started=" + $started)
  $r2 = & powershell.exe -NoProfile -NonInteractive -File "C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\Focus-Terminal.ps1" -TerminalPid $live.ProcessId -Started $started 2>&1
  Write-Output ("focus live result=[" + $r2 + "] code=" + $LASTEXITCODE)
} else { Write-Output 'no live piper proc found' }