import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const t = st.tasks.find(x => x.title === 'pipe-probe');
// accept the review task to finish it (human review gate), then shutdown
if (t.status === 'review') {
  const r = await fetch(base + '/admin/task/review', { method: 'POST', headers: H, body: JSON.stringify({ id: t.id, expectedRevision: t.revision, action: 'accept' }) });
  console.log('accept:', r.status, (await r.text()).slice(0, 100));
}
const r2 = await fetch(base + '/admin/shutdown', { method: 'POST', headers: H });
console.log('shutdown:', r2.status, (await r2.text()).slice(0, 80));