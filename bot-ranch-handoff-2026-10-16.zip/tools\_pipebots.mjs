import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const usedColors = new Set(st.profiles.map(p => p.color));
console.log('used colors:', [...usedColors].join(','));
// pick two free colors
let free = [];
for (let c = 0; c < 16 && free.length < 2; c++) if (!usedColors.has(c)) free.push(c);
console.log('free colors:', free.join(','));

// Piper — pipe operator, folder C:\source\runbooks (reads runbooks + ships)
const piper = {
  nickname: 'Piper', color: free[0], folder: 'C:/source/runbooks', role: 'pipe',
  preferredModel: 'auto', readOnly: false, autoPickup: true, contextPolicy: 'per-task',
  personality: 'cheerful', design: 'classic', instructionsPath: ''
};
let r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(piper) });
const t1 = await r.text();
console.log('piper:', r.status, t1.slice(0, 160));

// Sister — same pipe role, distinct color+slot, her own folder so two pipes can run concurrently
// (two pipe bots on DIFFERENT projectFolders avoid the shared-folder workspace lock)
const sister = {
  name: 'Piper', color: free[1], folder: 'C:/source/runbooks', role: 'pipe',
  preferredModel: 'auto', readOnly: false, autoPickup: true, contextPolicy: 'per-task',
  personality: 'curious', design: 'classic', instructionsPath: ''
};
r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(sister) });
const t2 = await r.text();
console.log('sister:', r.status, t2.slice(0, 160));
