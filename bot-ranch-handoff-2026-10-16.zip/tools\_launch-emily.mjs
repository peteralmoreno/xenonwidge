import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const em = st.profiles.find(p => p.nickname === 'Emily-pm');
if (!em) { console.log('Emily-pm missing'); process.exit(1); }
console.log('state:', em.state, em.status, 'actBusy', em.activityBusy);
const r = await fetch(base + '/admin/action', { method: 'POST', headers: H, body: JSON.stringify({ id: em.id, action: 'new' }) });
console.log('new:', r.status, (await r.text()).slice(0, 120));