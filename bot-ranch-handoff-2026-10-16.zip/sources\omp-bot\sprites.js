/* Original 32-ish pixel robot, drawn on a 64 x 64 grid. */
window.RanchSprites=(()=>{
 const rect=(x,y,w,h,fill,cls='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" class="${cls}"/>`;
 const ink='#233830',cream='#fff0bf';
 const colors=[['coral','#e58d77','#f8baa0'],['cyan','#68bbc3','#b0e3d7'],['gold','#ddb55c','#ffe3a1'],['violet','#a396ca','#d0c5eb'],['rose','#e78fb3','#ffd0e4'],['orange','#e8a05b','#ffd3a1'],['lime','#a8c966','#deeda5'],['emerald','#65b58e','#b4e5c7'],['blue','#729edb','#bfd8ff'],['indigo','#8585d5','#cccaff'],['silver','#bbc5cb','#ecf2f5'],['red','#cf7070','#ffc2b8'],['cream','#e4dcad','#fff1cf'],['mint','#66d9ce','#b8f4e9'],['orchid','#d976ed','#f3b5f7'],['copper','#a78362','#dec09d'],['hotred','#ff2d2d','#ff9b9b'],['magenta','#ff4dd8','#ffb8ef'],['sky','#2ec4ff','#b8e9ff'],['neon','#7cff3f','#d4ffb8'],['tangerine','#ff6b00','#ffb877'],['sun','#ffd400','#fff080'],['spring','#00e676','#8af7c9'],['teal','#00b8a9','#86e8dd'],['azure','#0a7dff','#9cc8ff'],['royal','#5e35ff','#b3a1ff'],['grape','#9b30ff','#d2a3ff'],['fuchsia','#ff0088','#ff99d0'],['watermelon','#ff4f6d','#ffb0bc'],['lavender','#b388ff','#e0d0ff'],['pearl','#ffffff','#f0f0f0'],['jet','#151515','#4d4d4d']];
 function svg(slot,state,design='classic'){
  const [,c,light]=(colors[slot]||colors[0]);let prop='',badge='';
  if(state==='reading')prop=rect(15,38,34,17,ink)+rect(17,40,13,12,cream)+rect(33,40,14,12,'#e6d79b')+rect(19,43,9,2,'#a99a68')+rect(35,43,9,2,'#a99a68');
  if(state==='researching')prop=`<path d="M43 27h12v3h3v12h-3v3H43v-3h-3V30h3z" fill="${ink}"/><path d="M44 31h10v10H44z" fill="#c3e4ca"/><path d="m41 43 4 4-9 9-4-4z" fill="${cream}"/>`;
  if(state==='writing')prop=rect(12,49,34,7,cream)+rect(17,51,19,2,'#a99a68')+`<path d="m34 47 11-17 5 3-11 17-6 3z" fill="#efc26c"/><path d="m33 53 1-6 5 3z" fill="${ink}"/>`;
  if(state==='running'||state==='working')prop=rect(13,39,38,17,ink)+rect(16,42,32,11,'#456255')+`<path d="m19 44 3 3-3 3m8 0h6" stroke="${cream}" stroke-width="2" fill="none"/>`;
  if(state==='thinking')badge=rect(45,15,3,3,cream)+rect(49,10,5,5,cream)+rect(55,3,7,7,cream);
  const marks={waiting:'?',done:'✓',error:'!',offline:'z'};
  if(marks[state])badge=rect(46,3,16,17,ink)+rect(48,5,12,13,state==='error'?'#f2a080':cream)+`<text x="54" y="15" text-anchor="middle" font-family="monospace" font-size="12" font-weight="bold" fill="${ink}">${marks[state]}</text>`;
  let result=`<svg class="sprite" viewBox="0 0 64 64" shape-rendering="crispEdges" aria-hidden="true"><g class="robot">${rect(18,56,30,3,'#38624b')}${rect(22,47,8,9,ink)}${rect(35,47,8,9,ink)}${rect(19,54,12,4,ink)}${rect(34,54,12,4,ink)}${rect(19,34,27,16,ink)}${rect(22,36,21,12,c)}${rect(27,38,11,6,ink)}${rect(30,40,5,2,cream)}<g class="arm">${rect(13,36,6,13,ink)}${rect(46,36,6,13,ink)}${rect(14,40,5,6,light)}${rect(46,40,5,6,light)}</g>${rect(30,8,4,8,ink)}${rect(28,5,8,5,cream)}${rect(16,16,33,18,ink)}${rect(19,13,27,24,ink)}${rect(19,16,27,17,c)}${rect(20,16,24,3,light)}${rect(22,21,21,10,ink)}${rect(25,24,4,state==='offline'?1:4,cream,'eye')}${rect(36,24,4,state==='offline'?1:4,cream,'eye')}${rect(12,22,4,8,ink)}${rect(49,22,4,8,ink)}<g class="prop">${prop}</g></g><g class="badge">${badge}</g><g class="hammer"><path d="M45 25h4v22h-4z" fill="#79583f"/><path d="M39 22h17v8H39z" fill="#c8cbbc" stroke="#233830" stroke-width="2"/></g><g class="celebration"><path d="M8 9h4v4H8zM14 3h3v5h-3zM51 2h4v4h-4zM57 24h4v4h-4zM5 28h3v5H5z" fill="#ffe3a1"/><path d="M3 18h4v4H3zM57 10h4v5h-4zM12 25h3v3h-3z" fill="#eab4a2"/></g><g class="nap"><text x="47" y="17" fill="#fff0bf" font-family="monospace" font-size="13">z</text><text x="56" y="9" fill="#fff0bf" font-family="monospace" font-size="9">z</text></g></svg>`;
  if(design==='pm'){
   // Little fedora: brim + crown, and dark sunglasses over the eyes.
   const hat='<g class="pm-hat"><rect x="16" y="6" width="32" height="4" fill="' + ink + '"/><rect x="21" y="9" width="22" height="7" fill="' + ink + '"/><rect x="21" y="9" width="22" height="2" fill="#456255"/></g>';
   const shades='<g class="pm-shades"><rect x="22" y="22" width="20" height="6" fill="#101820"/><rect x="24" y="24" width="3" height="2" fill="#eaf2f5"/><rect x="36" y="24" width="3" height="2" fill="#eaf2f5"/><path d="M42 24h4v3h-4z" fill="' + ink + '"/><path d="M19 24h3v3h-3z" fill="' + ink + '"/></g>';
   const pm = '<g class="pm">' + hat + shades + '</g>';
   result = result.replace(/(<g class="robot">)/, '$1' + pm);
  }
  if(design==='pipeline'){
   const pipe=`<g class="pipeline"><path d="M23 51v5h-6m24-5v5h6M24 39H14v8m26-8h10v8M32 30v17" fill="none" stroke="${ink}" stroke-width="10"/><path d="M23 51v5h-6m24-5v5h6M24 39H14v8m26-8h10v8M32 30v17" fill="none" stroke="${c}" stroke-width="6"/>${rect(23,34,18,17,ink)}${rect(26,36,12,13,c)}${rect(28,37,3,10,light)}<path d="M21 13h22v4h5v19h-5v4H21v-4h-5V17h5z" fill="${ink}"/><path d="M22 16h20v3h3v14h-3v4H22v-4h-3V19h3z" fill="${c}"/><path d="M24 19h16v3h3v10h-3v3H24v-3h-3V22h3z" fill="${cream}"/><path d="M25 23v3m14-3v3M31 21h3M32 30l5-6" stroke="${ink}" stroke-width="2"/><g class="eye">${rect(26,28,3,state==='offline'?1:3,ink)}${rect(36,28,3,state==='offline'?1:3,ink)}</g>${rect(29,5,6,9,ink)}${rect(22,4,20,4,ink)}${rect(25,3,14,3,light)}${rect(9,43,10,4,light)}${rect(45,43,10,4,light)}</g>`;
   result=result.replace(/(<g class="robot">)[\s\S]*?(<g class="prop">)/,'$1'+pipe+'$2');
  }
  return result;
 }
 return {colors,svg};
})();
