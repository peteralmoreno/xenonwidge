import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
// The widget shows NOTHING. Compare desk widget render data vs what /state provides.
// The desk app filters sessions: allSessions.slice(0,4) — only FIRST 4! Emily is #5 (slot 4). That's why Emily doesn't show!
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const st = await (await fetch(base + '/state', { headers: { Authorization: 'Bearer ' + key }, signal: AbortSignal.timeout(3000) })).json();
console.log('sessions returned:', (st.sessions || []).map(s => `${s.id.slice(-10)}:${s.project}:${s.state}`).join(' | '));
console.log('selectedId:', st.selectedId);
// desk widget code: sessions = allSessions.slice(0,4)
const d = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
const i = d.indexOf('slice(0,4)');
console.log('slice(0,4) at:', i, d.slice(i - 160, i + 40).replace(/\r/g, ''));
// What does the widget render for each session? bot badge creation:
const j = d.indexOf('buttons.set');
console.log(d.slice(j - 700, j + 120).replace(/\r/g, ''));