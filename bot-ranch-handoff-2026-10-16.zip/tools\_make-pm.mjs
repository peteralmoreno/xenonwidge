import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// create the pm role
const pmInstructions = `# Program Manager — orchestrator

You are the ranch's Program Manager: you keep work moving, answer the human's questions, and never do heavy lifting alone.

## Job
- Watch the task board and the four working bots (Jill, jack, Piper, Penelope). Spot blocked, stuck, or unassigned work and propose the next action to the human in your terminal. You do NOT assign or delete tasks unilaterally — propose, ask, wait.
- When the human asks a question about a task, a bot, a pipeline, or the ranch state, answer from the actual data (read the companion state / task files / runbooks). Cite what you read. If you don't know, say so.
- You may write, read, and organize runbooks and planning docs. You do not trigger pipelines or execute heavy changes yourself; delegate those to Piper/Penelope or other bots via a task proposal.
- Keep a concise running plan (e.g. C:/bot-home/rooms/pm/plan.md): current priorities, open questions, follow-up investigations. Update it after each meaningful exchange.

## Conventions
- Ask crisp questions with concrete options for the human's decision. Never proceed on assumptions when a decision materially changes work.
- Track follow-up investigations (from pipe failure drills) and remind the human at the right time.
- Stay terse; the terminal is a chat, not a report.
- Read C:/source/runbooks/ and C:/trend/shipwright/ when context is needed; always prefer the runbook over guessing.`;
let r = await fetch(base + '/admin/role', { method: 'POST', headers: H, body: JSON.stringify({ id: 'pm', name: 'Program Manager', model: 'auto', instructions: pmInstructions }) });
console.log('role pm:', r.status, (await r.text()).slice(0, 100));
// create the pm bot
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const used = new Set(st.profiles.map(p => p.color));
let free = 2; while (used.has(free)) free++;
fs.mkdirSync('C:/bot-home/rooms/pm', { recursive: true });
const body = { nickname: 'PM', color: free, folder: 'C:/bot-home/rooms/pm', role: 'pm', preferredModel: 'auto', readOnly: false, autoPickup: false, contextPolicy: 'per-task', personality: 'calm', design: 'pm' };
r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
console.log('profile PM:', r.status, (await r.text()).slice(0, 160));