import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// The widget polls /state and shows bot cards. If it STILL says disconnected, maybe:
// 1. the widget is not hitting the right base (the build's base = location.origin if served from desk… the iCUE widget serves files from a custom origin; base computes to http://127.0.0.1:43822 only when location.host === 127.0.0.1:43822 — otherwise fallback to http://127.0.0.1:43822 which is right.
// 2. iCUE sandbox may block network via CORS: check whether the server allows cross-origin. /state has no CORS headers; the widget is cross-origin (iCUE origin). The widget's fetch has no mode:'cors' but fetch defaults to cors => preflight fails unless server sends ACAO.
// server.mjs for /state: no CORS headers => iCUE widget cross-origin requests are blocked by the browser!
// Check server OPTIONS handling: server replies 204 to OPTIONS with no ACAO headers. That's the bug for widgets.
// Look at how setup/board accesses (paired widget) — maybe they use JSONP or served from same origin.
// Find CORS/ACAO in server.mjs
const s = fs.readFileSync('C:/source/xenonwidge/sources/omp-bot-companion/server.mjs', 'latin1');
console.log('ACAO:', s.includes('Access-Control-Allow-Origin'));
console.log('CORS:', s.includes('CORS') || s.includes('cors'));
// how does the SETUP board (widget) fetch? board.js
const b = fs.readFileSync('C:/source/xenonwidge/sources/omp-bot-companion/setup/board.js', 'latin1');
console.log('board fetch:', b.includes('fetch('));
for (const m of b.matchAll(/fetch\([^)]{0,90}/g)) console.log(m[0]);
// and how does the widget import get its key? appears the pair works only when served from the companion (same origin) — the iCUE sandbox might use puppeteer-like fetch that bypasses CORS, but if cors blocks, canvas shows quiet.
// Verify with a real browser cross-origin simulation: send Origin header + check response.
const r = await fetch(base + '/state', { headers: { Authorization: 'Bearer ' + key, Origin: 'https://icue-corsair.local' }, signal: AbortSignal.timeout(3000) });
console.log('/state with foreign Origin ->', r.status, '| ACAO:', r.headers.get('access-control-allow-origin'), '| body:', (await r.text()).slice(0, 60));