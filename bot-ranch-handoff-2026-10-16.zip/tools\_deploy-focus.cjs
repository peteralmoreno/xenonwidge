const fs = require('fs');
const src = 'C:/source/xenonwidge/tools/_clm-helpers/Terminal-Focus.exe';
const dsts = [
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/Terminal-Focus.exe',
  'C:/source/xenonwidge/sources/omp-bot-companion/Terminal-Focus.exe'
];
for (const d of dsts) {
  fs.copyFileSync(src, d);
  console.log('copied to', d, fs.statSync(d).size, 'bytes');
}
// also copy Focus-Terminal.ps1 unchanged already there; verify it invokes exe (it does).
console.log('exit0 focus verified live earlier');