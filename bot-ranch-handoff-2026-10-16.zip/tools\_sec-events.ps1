$ErrorActionPreference = 'SilentlyContinue'
Get-AppxLog -All -Recent 20 2>$null | Select-Object -First 5 | Out-String | Write-Output
Write-Output '=== security events (event log) ==='
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-AppLocker/EXE and DLL'; ID=8003,8004,8021} -MaxEvents 8 -ErrorAction SilentlyContinue | ForEach-Object { Write-Output ($_.TimeCreated.ToString() + ' ' + $_.Message.Substring(0,[Math]::Min(200,$_.Message.Length))) } | Out-String | Write-Output
Write-Output '=== WDAC/CodeIntegrity events ==='
Get-WinEvent -FilterHashtable @{LogName='Microsoft-Windows-CodeIntegrity/Operational'; ID=3076,3077,3083,3084} -MaxEvents 8 -ErrorAction SilentlyContinue | ForEach-Object { $_.Id.ToString() + ' ' + $_.Message.Substring(0,[Math]::Min(200,$_.Message.Length)) } | Out-String | Write-Output
Write-Output '=== smartscreen/appcompat ==='
Get-WinEvent -FilterHashtable @{LogName='Application'; ProviderName='Microsoft-Windows-AppModel-Runtime'} -MaxEvents 4 -ErrorAction SilentlyContinue | ForEach-Object { $_.Message.Substring(0,[Math]::Min(150,$_.Message.Length)) } | Out-String | Write-Output