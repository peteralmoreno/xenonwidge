import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// state check first
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const activeAttempts = st.tasks.flatMap(t => t.attempts || []).filter(a => ['dispatching', 'awaiting-runtime', 'claimed', 'running', 'unresolved'].includes(a.state));
console.log('activeAttempts:', activeAttempts.length);
console.log('locks busy:', st.profiles.some(p => p.busy));
for (const p of st.profiles) console.log(`${p.nickname}: state=${p.state} status=${p.status}`);
// call setHome
const r = await fetch(base + '/admin/settings', { method: 'POST', headers: H, body: JSON.stringify({ homeFolder: 'C:/bot-home' }) });
const body = await r.text();
console.log('setHome:', r.status, body.slice(0, 300));
// verify
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('new homeFolder:', st2.homeFolder);
const ranch = JSON.parse(fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'ranch.json'), 'utf8'));
console.log('ranch.json homeFolder:', ranch.homeFolder);