$ErrorActionPreference = 'SilentlyContinue'
$live = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'Bot Ranch - Piper' } | Select-Object -First 1
if (-not $live) { Write-Output 'no live piper'; exit 1 }
$proc = Get-Process -Id $live.ProcessId -ErrorAction SilentlyContinue
$started = $proc.StartTime.ToUniversalTime().Ticks.ToString()
Write-Output ("pid=" + $live.ProcessId + " started=" + $started)
# Run exactly what Focus-Terminal.ps1 does
$helper = 'C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\Terminal-Focus.exe'
$out = & $helper $live.ProcessId
$code = $LASTEXITCODE
Write-Output ("direct-exe exit=" + $code)
# Now the full PS1 script path
$r = & powershell.exe -NoProfile -NonInteractive -File "C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\Focus-Terminal.ps1" -TerminalPid $live.ProcessId -Started $started 2>&1
Write-Output ("ps1 result=[" + $r + "] code=" + $LASTEXITCODE)