const fs = require('fs');
const extra = ",'#ff2d2d','#ff4dd8','#2ec4ff','#7cff3f'";
const ORIG = "['#e58d77','#68bbc3','#ddb55c','#a396ca','#e78fb3','#e8a05b','#a8c966','#65b58e','#729edb','#8585d5','#bbc5cb','#cf7070','#e4dcad','#66d9ce','#d976ed','#a78362']";
const files = [
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/app.js',
  'C:/source/xenonwidge/sources/omp-bot/setup/app.js',
  'C:/source/xenonwidge/sources/omp-bot/setup/setup.mjs',
];
for (const f of files) {
  if (!fs.existsSync(f)) { console.log('skip', f); continue; }
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes("'#ff2d2d'")) { console.log('already 20:', f); continue; }
  if (c.includes(ORIG)) {
    const v = c.replace(ORIG, ORIG.replace(/\]$/, extra + ']'));
    if (v !== c) { fs.writeFileSync(f, v, 'latin1'); console.log('patched', f); }
    else console.log('no change', f);
  } else {
    console.log('ORIG missing in', f);
    // find a colors=[...] assignment nearby
    const m = c.match(/colors=(\[['\"][^;\]]{40,}?\])/);
    console.log('  found var:', m ? m[0].slice(0, 80) : 'none');
  }
}
// Also: the desk (ranch) color options? check desk/app.js for swatches
const desk = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
console.log('desk has color array:', (desk.match(/colors\s*=\s*\[[^\]]+\]/g) || []).length ? 'yes' : 'no');