const fs = require('fs');
const rj = JSON.parse(fs.readFileSync('C:/Users/petermo/AppData/Local/OmpBot/ranch.json', 'utf8'));
console.log('ranch.json widgetControlHash:', rj.widgetControlHash ? rj.widgetControlHash.slice(0, 24) + '...' : 'NOT SET');
for (const p of [
  'C:/bot-home/control-key.txt',
  'C:/Users/petermo/AppData/Local/OmpBot/control-key.txt',
  'C:/Users/petermo/AppData/Local/OmpBot/desktop/control-key.txt',
]) {
  console.log(p, fs.existsSync(p) ? 'EXISTS ' + fs.readFileSync(p, 'utf8').trim().slice(0, 16) : 'no');
}
const d = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
console.log('--- desk/app.js key handling ---');
for (const m of d.matchAll(/.{30}(key|control|localStorage|Authorization).{40}/g)) console.log(m[0].replace(/\n/g, ' '));