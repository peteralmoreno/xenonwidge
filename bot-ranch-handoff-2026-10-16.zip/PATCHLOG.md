# Bot Ranch Patchlog

Local patch log for the botRanch project (`C:/source/xenonwidge`).
Every entry = a machine-specific fix/feature NOT in the stock 0.17.1 release.
"Source" = the editable tree under `C:/source/xenonwidge/sources/`.
"Installed" = `C:\Users\petermo\AppData\Local\Programs\botRanch\versions\0.17.1\`.
"Release" = artifacts built with `tools/build.cjs` (`artifacts/releases/`).

Synchronization rule: every patch is applied to Source AND Installed AND (after the
next `build.cjs ranch build`) the Release, so a rebuild carries everything.

---

## 1. terminal-runner.mjs — dispatch watchdog (CRITICAL)

| | |
|---|---|
| Files | `omp-bot-companion/terminal-runner.mjs` (source + installed + release) |
| When | 2026-10-13/14 |
| Status | Done, verified end-to-end |

Stock behavior failed on this machine: the runner used `spawnSync(omp, …)` and relied on
the extension's `ctx.shutdown()` to exit OMP. On this OMP version a non-interactive ranch
session does NOT exit on shutdown, so the runner blocked forever inside `spawnSync`, never
consumed the `<binding>.next.json` handoff, never re-spawned with the task env, and the
60s ack timer marked every task "runtime did not acknowledge task start".

Rewrite:
- run OMP asynchronously (`spawn`)
- poll `<binding>.next.json` every 250 ms
- when the handoff appears, `taskkill /T /F /PID <child>` the omp tree so the loop
  unblocks, reads the handoff, and re-spawns `omp --extension … --session-dir …` with
  the task environment

Verified: task5 completed; task1/task3 run repeatedly; jack/Jill/Piper dispatch work.

## 2. Terminal focus — Windows 11 raise/no-steal

| | |
|---|---|
| Files | `Terminal-Focus.cs` (source), `Terminal-Focus.exe` (installed + release), `Focus-Terminal.ps1` |
| When | 2026-10-13 |
| Status | Done, verified |

Stock `Terminal-Focus.exe` imported `GetCurrentThreadId` from user32.dll (wrong DLL) →
`EntryPointNotFoundException` → every focus call failed as "security blocked".
- Rebuilt with `kernel32.dll` import + stronger Win11 foreground sequence; compiled with
  .NET Framework csc, deployed to installed + release.
- **No-steal focus is now the default**: SHOWNOACTIVATE + SWP_NOACTIVATE +
  HWND_TOPMOST/NOTOPMOST path; optional `steal` arg kept for the old behavior.
- `Focus-Terminal.ps1` delegates to the exe; identity check stays:
  `Get-Process -Id <pid>` must be mintty and StartTime must equal the Started param.

User preference: window raises without stealing keyboard focus.

## 3. Terminal-Close.exe

| | |
|---|---|
| Files | `Terminal-Close.exe` (installed + release); source C# in repo |
| Status | Done |

CLM-safe terminal close helper (no .NET method calls / Add-Type / COM in PowerShell —
WDAC/VBS constraints). Companion stop flow uses it.

## 4. pm design (sprite + validation)

| | |
|---|---|
| Files | `omp-bot/sprites.js` (pm branch: fedora + sunglasses), `omp-bot/ui`-shipped `app.js` (design select includes `'pm'`), `omp-bot-companion/manager.mjs` + `bot-library.mjs` (validation accepts `'pm'`; messages "Choose Classic, Pipeline, or PM design.") |
| Status | Done |

Design validation in manager + bot-library extended; manager's on-load coercion
(`design:['classic','pipeline'].includes(p.design)?…`) extended to include `'pm'` —
otherwise a saved `pm` profile reloads as `classic`.

## 5. pipeOnly task gating

| | |
|---|---|
| Files | `omp-bot-companion/manager.mjs` (source + installed + release) |
| Status | Done, verified |

- `saveTask` validates boolean `pipeOnly`
- task object carries `pipeOnly`
- `stickyEligible` returns false when `task.pipeOnly === true` unless
  `profile.role === 'pipe' || 'pipeline'`
- `publicTask` exposes `pipeOnly`
- `waitingReason` explains the pipe-only wait

Verified: `pipe-catalog-probe` (pipeOnly) picked up by Piper, NOT by jack/Jill.

## 6. Bot home moved to C:\bot-home

| | |
|---|---|
| Files | settings (`homeFolder: 'C:/bot-home'` via `POST /admin/settings`) |
| Status | Done |

Roles/bots/tasks/handovers migrated; `C:/bot-home` now holds `bots/ roles/ sessions/
tasks/ handovers/ botRanch.md`. Verified live + in ranch.json.

## 7. Per-bot rooms under C:\bot-home\rooms\<nickname>

| | |
|---|---|
| Files | profile `folder` values; room directories created |
| Status | Done |

Each bot's workspace is its own room (jill, jack, piper, penelope, emily-pm).
Removes the shared-folder workspace-lock serialization between pipe bots, enabling
concurrent pipelines.

## 8. Palette expanded 16 → 20 → 32 colors

| | |
|---|---|
| Files | `omp-bot/sprites.js`, `omp-bot-companion/manager.mjs` + `bot-library.mjs` (color range 0-31), `omp-bot-companion/setup/app.js` (+`colorNames`), `setup/board.js`, `ranch-desk/app.js` (desk widget), desktop `renderer.js` (`xc` swatches + `PT` names), installed mirrors of all of the above |
| Status | Done |

+4 (20): hotred `#ff2d2d`, magenta `#ff4dd8`, sky `#2ec4ff`, neon `#7cff3f`.
+12 vibrant (32): tangerine `#ff6b00`, sun `#ffd400`, spring `#00e676`, teal `#00b8a9`,
azure `#0a7dff`, royal `#5e35ff`, grape `#9b30ff`, fuchsia `#ff0088`,
watermelon `#ff4f6d`, lavender `#b388ff`, pearl `#ffffff`, jet `#151515`.

Classic/bright fix: setup `colorNames` (labels) and renderer `PT` (names) were 16 while
swatch arrays grew — labels now stay in lockstep so no swatch reads "undefined".

## 9. Emily-pm (bot: PM design)

| | |
|---|---|
| Files | profile created (id `5624596d-…`), nickname `Emily-pm`, design `pm`, color 16 (hotred), folder `C:\bot-home\rooms\emily-pm`, role `pm`, autoPickup off |
| Status | Done |

User chose: PM bot named "Emily-pm", bright red (hotred), no auto pickup.

## 10. pm role (Product Manager) + pipe role

| | |
|---|---|
| Files | roles created via admin API; instructions in `C:\bot-home\roles\pm\agent.md`, `C:\bot-home\roles\pipe\agent.md` |
| Status | Done |

- `pipe` role: runbooks-first operator; triggers `/api/workflows/trigger` with exact
  workflow_name/payload; babysits via polling; alert-first failure drill; NEVER starts
  unpaid re-runs without user approval.
- `pm` role: watcher of the board + bots; proposes next actions; answers from real data;
  delegates heavy/pipe work; keeps running plan at `rooms/<name>/plan.md`.


Role display-name history: created as "Program Manager" (2026-10-14), renamed "Project
Manager" mid-session, then corrected to **"Product Manager"** per user requirement
(2026-10-14, role `pm` id kept, revision bumped).

## 11. Pipe workspace convention (user rule)

| | |
|---|---|
| Files | `roles/pipe/agent.md`; task `projectFolder` behavior |
| Status | Done |

- Runbooks (`C:/source/runbooks/`), api-cli skill, `C:/trend/shipwright*` are
  **read-only references** unless the task explicitly says "work ON the runbooks".
- Pipe tasks do NOT get a target location; bots work in their own room.
- Observations/details/scratch go to `.scratch/` under the bot's room.

## 12. Desktop dock.css tint fix

| | |
|---|---|
| Files | `omp-bot-desktop/dock.css` (33% tint over `#1c1c21`, 78% border) + installed `desktop/resources/app/dock.css` |
| Status | Done |

## 13. CLM-safe PowerShell rewrites

| | |
|---|---|
| Files | `Focus-Terminal.ps1`, `Terminal-Control.ps1`, `Start-Bot-Ranch.ps1` (no .NET method calls, no Add-Type, no COM) |
| Status | Done |

All PS under Constrained Language Mode (WDAC/VBS); native helpers compiled with .NET
Framework csc (`Terminal-Focus.exe`, `Terminal-Close.exe`, `ZipRelease.exe`).

## 14. OMP safety layers (runtime config, not repo code)

| | |
|---|---|
| Files | `C:\Users\petermo\.omp\agent\RULES.md`, `APPEND_SYSTEM.md`, `config.yml`, `hooks/pre/omp-rules.ts` |
| Status | Active |

`hideThinkingBlock=false`, `display.hideToolActivity=false` per user (visibility);
safety rules + proseOnlyThinking stay on.

---

## Open items

- `VERSIONING.md` describes the 0.18 process; nothing bumped yet.
- `sources/` tree not under git yet — diff history starts when we `git init`.