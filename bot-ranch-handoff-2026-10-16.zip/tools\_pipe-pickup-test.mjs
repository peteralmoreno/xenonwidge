import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const t = st.tasks.find(x => x.title === 'pipe-probe');
console.log('pipe-probe:', JSON.stringify({ id: t.id, pipeOnly: t.pipeOnly, status: t.status, waitingReason: t.waitingReason }, null, 1));
// All four bots have autoPickup on; release it and see WHO picks it up (should be Piper or Penelope only)
const body = { id: t.id, title: t.title, projectFolder: t.projectFolder, instructions: t.instructions, acceptanceCriteria: t.acceptanceCriteria, reasoningRequest: t.reasoningRequest, humanReview: t.humanReview, releasedForPickup: true, expectedRevision: t.revision, stickyMode: t.stickyMode, pipeOnly: t.pipeOnly, assignedProfileId: null };
const r = await fetch(base + '/admin/task', { method: 'POST', headers: H, body: JSON.stringify(body) });
console.log('release:', r.status, (await r.text()).slice(0, 100));
// watch 30s
for (let i = 0; i < 10; i++) {
  await new Promise(res => setTimeout(res, 3000));
  const s2 = await (await fetch(base + '/admin/state', { headers: H })).json();
  const t2 = s2.tasks.find(x => x.title === 'pipe-probe');
  const a = (t2.attempts || []).at(-1);
  const owner = a ? s2.profiles.find(p => p.id === a.profileId)?.nickname : '-';
  console.log(`t+${(i + 1) * 3}s status=${t2.status} owner=${owner} last=${a?.state}`);
  if (a?.state === 'running' || a?.state === 'claimed' || a?.state === 'awaiting-runtime') { console.log('PICKED UP by', owner); break; }
}