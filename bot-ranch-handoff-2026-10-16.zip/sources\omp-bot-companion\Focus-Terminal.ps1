param([Parameter(Mandatory=$true)][int]$TerminalPid,[Parameter(Mandatory=$true)][string]$Started)
$ErrorActionPreference = 'Stop'
try {
    $terminalProcess = Get-Process -Id $TerminalPid -ErrorAction SilentlyContinue
    if (-not $terminalProcess) { Write-Output 'closed'; exit }
    if ($terminalProcess.ProcessName -ne 'mintty' -or $terminalProcess.StartTime.ToUniversalTime().Ticks.ToString() -ne $Started) { Write-Output 'closed'; exit }
    $terminalWindow = $terminalProcess.MainWindowHandle
    if ($terminalWindow -eq [IntPtr]::Zero) { Write-Output 'unavailable'; exit }
    # CLM-safe: Add-Type P/Invoke and [ref] are blocked in Constrained Language Mode.
    # Delegate window focus to the bundled native helper.
    $focus = Join-Path $PSScriptRoot 'Terminal-Focus.exe'
    if (-not (Test-Path -LiteralPath $focus)) { Write-Output 'unavailable'; exit }
    & $focus $TerminalPid ([long]$terminalWindow)
    if ($LASTEXITCODE -eq 0) { Write-Output 'focused' } else { Write-Output 'attention' }
} catch { Write-Output 'unavailable' }