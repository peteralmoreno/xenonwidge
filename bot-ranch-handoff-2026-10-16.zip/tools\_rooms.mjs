import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };

// 1. create rooms
const rooms = ['jill', 'jack', 'piper', 'penelope'];
for (const r of rooms) fs.mkdirSync(path.join('C:/bot-home/rooms', r), { recursive: true });
console.log('rooms created:', fs.readdirSync('C:/bot-home/rooms').join(','));

// 2. repoint each profile to C:/bot-home/rooms/<nickname-lower>
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st.profiles) {
  const room = path.join('C:/bot-home/rooms', p.nickname.toLowerCase());
  const body = { id: p.id, nickname: p.nickname, color: p.color, folder: room, role: p.role, preferredModel: p.preferredModel, readOnly: p.readOnly, autoPickup: p.autoPickup, contextPolicy: p.contextPolicy, personality: p.personality, design: p.design, instructionsPath: p.instructionsPath, expectedRevision: p.revision };
  const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
  const t = await r.text();
  console.log(`${p.nickname}: ${r.status} ${t.slice(0, 120)}`);
}
// 3. verify
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st2.profiles) console.log(`${p.nickname} Ã¢ÂÂ ${p.folder}`);