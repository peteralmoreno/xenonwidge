$ErrorActionPreference = 'SilentlyContinue'
# Kill piper's tree (she's stuck on the catalog probe and blocks the companion restart)
$all = Get-CimInstance Win32_Process
$roots = $all | Where-Object { $_.CommandLine -match 'Bot Ranch - Piper' }
$ids = @()
foreach ($r in $roots) {
  $ids += $r.ProcessId
  $queue = @($r.ProcessId)
  $seen = @{}
  while ($queue.Count) {
    $cur = $queue[0]; $queue = @($queue[1..($queue.Count - 1)])
    if ($seen.ContainsKey($cur)) { continue }
    $seen[$cur] = $true
    foreach ($c in $all) { if ($c.ParentProcessId -eq $cur) { $queue += $c.ProcessId } }
  }
  $ids += @($seen.Keys)
}
$ids = $ids | Select-Object -Unique
foreach ($id in $ids) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 1500
Write-Output ('killed piper: ' + ($ids -join ','))