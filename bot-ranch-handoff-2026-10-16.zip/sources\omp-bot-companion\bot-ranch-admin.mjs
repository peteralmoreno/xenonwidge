import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const keyFile = path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt');
const base = 'http://127.0.0.1:43822';
const H = () => ({ Authorization: 'Bearer ' + fs.readFileSync(keyFile, 'utf8').trim(), 'Content-Type': 'application/json' });

async function api(method, route, body) {
  const res = await fetch(base + route, { method, headers: H(), body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(8000) });
  const text = await res.text();
  let json; try { json = JSON.parse(text); } catch { json = text; }
  if (!res.ok) throw new Error(route + ' ' + res.status + ': ' + (json?.error || text).slice(0, 300));
  return json;
}

// ---- READ ----
export const getState = () => api('GET', '/admin/state');
export const getHealth = () => api('GET', '/admin/health');
export const getChecks = () => api('GET', '/admin/checks');
export const getTasks = async () => (await getState()).tasks;
export const getProfiles = async () => (await getState()).profiles;
export const getRoles = async () => (await getState()).roles;

// ---- TASKS ----
export const createTask = async (t) => {
  // A NEW task insert must carry the CURRENT board revision (taskRevision from /admin/state),
  // otherwise the server answers 409 'task changed in another view'.
  const st = await getState();
  return api('POST', '/admin/task', {
    title: t.title,
    instructions: t.instructions,
    acceptanceCriteria: t.acceptanceCriteria || '',
    projectFolder: t.projectFolder || 'C:/bot-home',
    reasoningRequest: t.reasoningRequest || 'auto',
    modelEligibility: t.modelEligibility || [],
    humanReview: !!t.humanReview,
    pipeOnly: !!t.pipeOnly,
    releasedForPickup: t.releasedForPickup ?? true,
    assignedProfileId: t.assignedProfileId ?? null,
    stickyMode: t.stickyMode || 'inherit',
    expectedRevision: st.taskRevision,
  });
};
export const updateTask = (id, expectedRevision, patch) => api('POST', '/admin/task', { id, expectedRevision, ...patch });
export const dispatchTask = (taskId, profileId, expectedRevision) => api('POST', '/control/task/start', { taskId, profileId, expectedRevision });
export const stopTask = (id, expectedAttemptId, confirmed = true) => api('POST', '/admin/task/stop', { id, confirmed, expectedAttemptId });
export const reviewTask = (id, expectedRevision, action, note = '') => api('POST', '/admin/task/review', { id, expectedRevision, action, note });
export const archiveTask = (id, expectedRevision) => api('POST', '/admin/task/archive', { id, expectedRevision });
export const retryTask = (id, expectedRevision) => api('POST', '/admin/task/retry', { id, expectedRevision });
export const queueTask = (id, profileId, beforeTaskId, expectedRevision, expectedQueueRevision) =>
  api('POST', '/admin/task/queue', { id, profileId, beforeTaskId, expectedRevision, expectedQueueRevision });
export const setTaskSticky = (id, expectedRevision, stickyMode) => api('POST', '/admin/task/sticky', { id, expectedRevision, stickyMode });

// ---- PROFILES ----
export const getProfile = async (nickname) => (await getProfiles()).find(p => p.nickname.toLowerCase() === nickname.toLowerCase());
export const newBot = (p) => api('POST', '/admin/profile', {
  nickname: p.nickname, color: p.color ?? 0, role: p.role ?? 'generalist',
  folder: p.folder || ('C:/bot-home/rooms/' + p.nickname.toLowerCase()),
  preferredModel: p.preferredModel || '', design: p.design || 'classic',
  readOnly: !!p.readOnly, autoPickup: !!p.autoPickup, contextPolicy: p.contextPolicy || 'trim',
  personality: p.personality || 'calm', instructionsPath: p.instructionsPath || '',
});
export const updateProfile = (p) => api('POST', '/admin/profile', { ...p, expectedRevision: p.revision });
export const toggleAutoPickup = async (nickname, on) => {
  const p = await getProfile(nickname);
  if (!p) throw new Error('No profile named ' + nickname);
  return api('POST', '/admin/profile', { ...p, autoPickup: !!on });
};
export const actionOnProfile = (id, action) => api('POST', '/admin/action', { id, action });

// ---- SETTINGS / MISC ----
export const setHome = (homeFolder) => api('POST', '/admin/settings', { homeFolder });
export const ringAll = () => api('POST', '/admin/profile/ring-all', {});
export const requestWorkCheck = (id) => api('POST', '/admin/profile/check-work', { id });
export const setPickupPaused = (paused) => api('POST', '/control/pickup', { paused });
export const shutdown = () => api('POST', '/admin/shutdown');

// ---- REPORT ----
export function summarizeState(st) {
  const profiles = st.profiles.map(p => `${p.nickname} (${p.role}, ${p.state}/${p.status}, auto=${p.autoPickup})`).join('; ');
  const tasks = (st.tasks || []).filter(t => !t.archived).map(t => {
    const attempt = t.attempts?.at(-1);
    return `${t.id.slice(0, 8)} ${t.title} [${t.status}] ${attempt ? attempt.state : ''} ${t.assignedProfileId ? '@' + t.assignedProfileId.slice(0, 8) : 'pool'}`;
  }).join('; ');
  return `PROFILES: ${profiles}\nTASKS: ${tasks}`;
}