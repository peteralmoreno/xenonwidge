const fs = require('fs');
const OLD16 = '"#e58d77","#68bbc3","#ddb55c","#a396ca","#e78fb3","#e8a05b","#a8c966","#65b58e","#729edb","#8585d5","#bbc5cb","#cf7070","#e4dcad","#66d9ce","#d976ed","#a78362"';
const NEW20 = OLD16 + ',"#ff2d2d","#ff4dd8","#2ec4ff","#7cff3f"';
const files = [
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/renderer.js',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/board.js',
];
for (const f of files) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes('#ff2d2d')) { console.log('already 20:', f); continue; }
  if (c.includes(OLD16)) { fs.writeFileSync(f, c.replace(OLD16, NEW20), 'latin1'); console.log('patched', f); }
  else { console.log('missing arr', f); }
}
// also names PT array? add names for new colors in renderer
let r = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/renderer.js', 'latin1');
const m = r.match(/PT=\["Coral[^\]]*\]/);
console.log('names:', m ? m[0].slice(0, 200) : 'none');
if (m && !r.includes('"Hot Red"')) {
  const names = r.replace(m[0], m[0].replace(/\]$/, ',"Hot Red","Magenta","Sky","Neon"\]'));
  fs.writeFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/renderer.js', names, 'latin1');
  console.log('names extended');
}