import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const k = (await (await fetch(base + '/admin/key', { headers: H })).json()).key;
const r = await fetch(base + '/state', { headers: { Authorization: 'Bearer ' + k }, signal: AbortSignal.timeout(3000) });
const st = await r.json();
console.log('desk /state ->', r.status);
console.log('sessions count:', (st.sessions || []).length);
console.log('keys:', Object.keys(st).join(','));
for (const s of (st.sessions || []).slice(0, 6)) console.log('session:', JSON.stringify({ id: s.id, project: s.project, state: s.state, label: s.label, profileId: s.profileId, managed: s.managed, metadata: s.metadata ? Object.keys(s.metadata) : null }).slice(0, 180));
console.log('selectedId:', st.selectedId);
// also check manager.residents from admin state — profiles active/slot
const a = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('active profiles:', a.profiles.map(p => `${p.nickname}: active=${p.active} slot=${p.slot} state=${p.state}`).join(' | '));