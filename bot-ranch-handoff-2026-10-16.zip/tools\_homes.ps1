$ErrorActionPreference = 'SilentlyContinue'
Write-Output '--- C:\bot-home contents ---'
Get-ChildItem 'C:\bot-home' -Force -Recurse -Depth 1 | Select-Object FullName | Format-Table -AutoSize -Wrap | Out-String | Write-Output
Write-Output '--- old home contents (should remain) ---'
Get-ChildItem 'C:\Users\petermo\AppData\Local\OmpBot\bot-home' -Force | Select-Object Name | Format-Table -AutoSize | Out-String | Write-Output