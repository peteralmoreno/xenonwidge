import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// Find jack's run attempt binding; the tree was killed so reconcile should have interrupted. Check.
let st = await (await fetch(base + '/admin/state', { headers: H })).json();
let t = st.tasks.find(x => x.title === 'pipe-probe');
let a = (t.attempts || []).at(-1);
console.log('pipe-probe:', t.status, 'last=', a?.state, 'err=', (a?.error || '').slice(0, 60));
if (!['blocked', 'todo', 'done'].includes(t.status) && a) {
  // If still active, mark interrupted by killing the run binding's terminal (already dead) — reconcile should catch.
  await new Promise(r => setTimeout(r, 15000));
  st = await (await fetch(base + '/admin/state', { headers: H })).json();
  t = st.tasks.find(x => x.title === 'pipe-probe');
  a = (t.attempts || []).at(-1);
  console.log('after wait: pipe-probe:', t.status, 'last=', a?.state);
}
const shutdown = await fetch(base + '/admin/shutdown', { method: 'POST', headers: H });
console.log('shutdown:', shutdown.status, (await shutdown.text()).slice(0, 80));