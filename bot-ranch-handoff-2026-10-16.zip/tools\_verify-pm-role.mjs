import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// verify role instruction is served by the companion (state shows instructionsPath; manager reads the file live per profile)
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const pm = st.roles.find(r => r.id === 'pm');
console.log('role pm:', pm.name, '| instructionsPath:', pm.instructionsPath, '| instructions head:', (pm.instructions||'').slice(0,90));
const em = st.profiles.find(p => p.nickname === 'Emily-pm');
console.log('Emily-pm:', em.role, '| folder:', em.folder, '| design:', em.design, '| color:', em.color);