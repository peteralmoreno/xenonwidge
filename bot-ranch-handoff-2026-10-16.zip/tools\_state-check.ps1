$ErrorActionPreference = 'SilentlyContinue'
$c = Test-NetConnection -ComputerName 127.0.0.1 -Port 43822 -InformationLevel Quiet -WarningAction SilentlyContinue
Write-Output ("port43822=" + $c)
Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'botRanch|mintty|Terminal' } | Select-Object ProcessId,Name,@{n='cmd';e={$_.CommandLine.Substring(0,[Math]::Min(90,$_.CommandLine.Length))}} | Format-Table -AutoSize -Wrap | Out-String | Write-Output