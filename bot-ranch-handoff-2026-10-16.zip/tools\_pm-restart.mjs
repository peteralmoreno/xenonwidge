import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// verify which manager the live companion runs (patched one accepts pm) — it doesn't, so restart companion required.
// Before restart: check for active attempts
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const active = st.tasks.flatMap(t => t.attempts || []).filter(a => ['dispatching','awaiting-runtime','claimed','running','unresolved'].includes(a.state));
const busyProfiles = st.profiles.filter(p => p.activityBusy);
console.log('active attempts:', active.length, 'busy profiles:', busyProfiles.map(p=>p.nickname).join(',') || 'none');
// All terminals closed? profiles offline/closed = yes
for (const p of st.profiles) console.log(p.nickname, p.state, p.status);
// shutdown
const r = await fetch(base + '/admin/shutdown', { method: 'POST', headers: H });
console.log('shutdown:', r.status, (await r.text()).slice(0, 60));