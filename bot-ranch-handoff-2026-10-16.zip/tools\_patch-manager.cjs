const fs = require('fs');
const targets = [
  'C:/source/xenonwidge/sources/omp-bot-companion/manager.mjs',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/manager.mjs',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/pickup-policy.mjs',
  'C:/source/xenonwidge/sources/omp-bot-companion/pickup-policy.mjs',
];

function patch(file, pairs) {
  let c = fs.readFileSync(file, 'latin1');
  for (const [find, put] of pairs) {
    if (!c.includes(find)) { console.error('MISSING in ' + file + ': ' + find.slice(0, 80)); continue; }
    c = c.replace(find, put);
  }
  fs.writeFileSync(file, c, 'latin1');
  console.log('patched', file);
}

// 1. manager.mjs — validation
patch(targets[0], [
  [
    "if(input.releasedForPickup!==undefined&&typeof input.releasedForPickup!=='boolean')throw Error('Automatic pickup release must be true or false.');",
    "if(input.releasedForPickup!==undefined&&typeof input.releasedForPickup!=='boolean')throw Error('Automatic pickup release must be true or false.');if(input.pipeOnly!==undefined&&typeof input.pipeOnly!=='boolean')throw Error('Pipe-only flag must be true or false.');"
  ],
  // 2. task construction — carry pipeOnly
  [
    "archived:previous?.archived||false,attempts:previous?.attempts||[],",
    "pipeOnly:input.pipeOnly??previous?.pipeOnly??false,archived:previous?.archived||false,attempts:previous?.attempts||[],"
  ],
]);
patch(targets[1], [
  [
    "if(input.releasedForPickup!==undefined&&typeof input.releasedForPickup!=='boolean')throw Error('Automatic pickup release must be true or false.');",
    "if(input.releasedForPickup!==undefined&&typeof input.releasedForPickup!=='boolean')throw Error('Automatic pickup release must be true or false.');if(input.pipeOnly!==undefined&&typeof input.pipeOnly!=='boolean')throw Error('Pipe-only flag must be true or false.');"
  ],
  [
    "archived:previous?.archived||false,attempts:previous?.attempts||[],",
    "pipeOnly:input.pipeOnly??previous?.pipeOnly??false,archived:previous?.archived||false,attempts:previous?.attempts||[],"
  ],
]);
// 3. pickup-policy.mjs — pipe-only gating in eligibleFor/selectPickupTask
// The gate goes in the manager's stickyEligible (profile has .role) — pipe bots have role 'pipe'.
patch(targets[2], []);
patch(targets[3], []);
console.log('pickup-policy gating: see manager stickyEligible patch next');
