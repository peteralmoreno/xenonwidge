const fs = require('fs');
const roots = ['C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1', 'C:/source/xenonwidge/sources'];
for (const root of roots) {
  (function walk(d) {
    for (const n of fs.readdirSync(d)) {
      const f = d + '/' + n;
      const s = fs.statSync(f);
      if (s.isDirectory()) { if (!n.startsWith('.') && n !== 'node_modules') walk(f); }
      else if (n.toLowerCase().includes('widget') || n.toLowerCase().includes('icue')) {
        const c = fs.readFileSync(f, 'latin1').toLowerCase();
        console.log('WIDGET:', f, c.includes('#cf7070') ? 'PALETTE' : c.includes('color') ? '(color)' : '');
      }
    }
  })(root);
}