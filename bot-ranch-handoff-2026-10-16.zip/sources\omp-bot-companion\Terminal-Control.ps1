param([ValidateSet('status','close')][string]$Action,[int]$TerminalPid,[string]$Started,[ValidateSet('terminal','launcher')][string]$Kind='terminal')
$ErrorActionPreference = 'Stop'
try {
    $terminalProcess = Get-Process -Id $TerminalPid -ErrorAction SilentlyContinue
    $expectedName = if ($Kind -eq 'launcher') { 'powershell' } else { 'mintty' }
    if (-not $terminalProcess -or $terminalProcess.ProcessName -ne $expectedName -or $terminalProcess.StartTime.ToUniversalTime().Ticks.ToString() -ne $Started) { Write-Output 'closed'; exit }
    if ($Action -eq 'status') { Write-Output 'live'; exit }
    if ($Kind -ne 'terminal') { Write-Output 'unavailable'; exit }
    # CLM-safe: CloseMainWindow() / WaitForExit() are blocked in Constrained Language Mode.
    # Delegate close to the bundled native helper.
    $closer = Join-Path $PSScriptRoot 'Terminal-Close.exe'
    if (Test-Path -LiteralPath $closer) {
        & $closer $TerminalPid
        if ($LASTEXITCODE -eq 0) { Write-Output 'closed'; exit }
        Write-Output 'attention'; exit
    }
    Write-Output 'unavailable'; exit
} catch { Write-Output 'unavailable' }