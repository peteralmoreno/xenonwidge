import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
let st, t, a;
try {
  st = await (await fetch(base + '/admin/state', { headers: H })).json();
  console.log('== profiles ==');
  for (const p of st.profiles) console.log(`${p.nickname}: ${p.state}/${p.status} busy=${p.busy} actBusy=${p.activityBusy} auto=${p.autoPickup}`);
  console.log('== tasks ==');
  for (const t of st.tasks) {
    const a = (t.attempts || []).at(-1);
    console.log(`task ${t.title}: ${t.status} rel=${t.releasedForPickup} last=${a?.state || '-'} wait=${(t.waitingReason || '-').slice(0, 60)}`);
  }
  // clean shutdown if possible
  const r = await fetch(base + '/admin/shutdown', { method: 'POST', headers: H });
  console.log('shutdown:', r.status, (await r.text()).slice(0, 120));
} catch (e) { console.log('ERR:', e.message); }