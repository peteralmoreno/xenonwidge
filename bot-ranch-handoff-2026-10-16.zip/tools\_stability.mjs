import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// The server has CORS open (*). 401 "Pairing key rejected" came from my test with the SESSION key + foreign Origin — wait, that's odd. Let me retest carefully: maybe the key I used was stale after companion restart? companion pid changed earlier (45540). /admin/key returns a key — but is it stable across restarts? Re-fetch key + test both /state and /desk/ in one run.
const k1 = (await (await fetch(base + '/admin/key', { headers: H })).json()).key;
console.log('session key now:', k1.slice(0, 16) + '...');
for (const origin of [null, 'https://icue.corsair.local']) {
  const hdrs = { Authorization: 'Bearer ' + k1 };
  if (origin) hdrs.Origin = origin;
  const r = await fetch(base + '/state', { headers: hdrs, signal: AbortSignal.timeout(3000) });
  console.log('/state', origin ? 'origin' : 'no-origin', '->', r.status, (await r.text()).slice(0, 50));
}
// maybe the widget needs the key WITHOUT 'Bearer ' prefix? check desk request(): headers Authorization Bearer.
// also check the widget actual URL the launcher opens — maybe it passes key via hash #pair=
const ck = fs.readFileSync('C:/bot-home/control-key.txt', 'utf8').trim();
const r2 = await fetch(base + '/state?key=' + ck, { headers: { Origin: 'https://icue.corsair.local' }, signal: AbortSignal.timeout(3000) });
console.log('/state?key= query ->', r2.status, (await r2.text()).slice(0, 50));