$ErrorActionPreference = 'SilentlyContinue'
# Kill jack's tree (the one that picked up pipe-probe) so the companion can restart.
$all = Get-CimInstance Win32_Process
$roots = $all | Where-Object { $_.CommandLine -match 'Bot Ranch - jack' }
$ids = @()
foreach ($r in $roots) {
  $ids += $r.ProcessId
  $queue = @($r.ProcessId)
  while ($queue.Count) {
    $cur = $queue[0]
    $queue = @($queue[1..($queue.Count - 1)])
    foreach ($c in $all) { if ($c.ParentProcessId -eq $cur) { $ids += $c.ProcessId; $queue += $c.ProcessId } }
  }
}
$ids = $ids | Select-Object -Unique
foreach ($id in $ids) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 1500
Write-Output ('killed jack tree: ' + ($ids -join ','))