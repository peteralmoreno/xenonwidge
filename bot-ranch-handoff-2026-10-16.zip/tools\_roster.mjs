import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st.profiles) {
  console.log(`${p.nickname.padEnd(8)} slot=${p.slot} color=${p.color} role=${p.role.padEnd(12)} folder=${p.folder} autoPickup=${p.autoPickup} state=${p.state}`);
}
console.log('roles:', st.roles.map(r => r.id).join(','));
// sanity: ranchSlots 0-5, colors must be unique among active
const active = st.profiles.filter(p => p.active);
console.log('active count:', active.length, 'slots:', active.map(p => p.slot).join(','), 'colors:', active.map(p => p.color).join(','));