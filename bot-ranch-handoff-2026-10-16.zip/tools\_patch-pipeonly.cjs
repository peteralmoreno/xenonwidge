const fs = require('fs');
const files = [
  'C:/source/xenonwidge/sources/omp-bot-companion/manager.mjs',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/manager.mjs',
];
const gate = "if(task.pipeOnly===true&&profile.role!=='pipe'&&profile.role!=='pipeline')return false;";
for (const file of files) {
  let c = fs.readFileSync(file, 'latin1');
  // 1. stickyEligible gate: insert right after the retirement/active guards, before pickupBlockReason
  const anchor = "return false;if(task.pickupBlockReason||dependencyReason(task,this.tasks)||workspaceReason(task,this.tasks))return false;";
  if (c.includes(anchor)) {
    c = c.replace(anchor, "return false;" + gate + "if(task.pickupBlockReason||dependencyReason(task,this.tasks)||workspaceReason(task,this.tasks))return false;");
    console.log('gate inserted in', file);
  } else console.error('ANCHOR MISSING in', file);
  // 2. expose pipeOnly in publicTask
  const pubAnchor = "return {...task,sticky:resolvedSticky(task,this.familyPolicies),";
  if (c.includes(pubAnchor) && !c.includes("pipeOnly:task.pipeOnly")) {
    c = c.replace(pubAnchor, "return {...task,pipeOnly:task.pipeOnly===true,sticky:resolvedSticky(task,this.familyPolicies),");
    console.log('publicTask exposes pipeOnly in', file);
  } else if (!c.includes(pubAnchor)) console.error('PUB ANCHOR MISSING in', file); else console.log('pub already patched in', file);
  fs.writeFileSync(file, c, 'latin1');
}
// 3. waitingReason: add pipe-bot explanation
for (const file of files) {
  let c = fs.readFileSync(file, 'latin1');
  const wAnchor = "if(!task.releasedForPickup)return 'Inbox: release when ready.';";
  if (c.includes(wAnchor) && !c.includes("Pipe-only task")) {
    c = c.replace(wAnchor, "if(!task.releasedForPickup)return 'Inbox: release when ready.';if(task.pipeOnly===true){const pipes=this.profiles.filter(p=>p.role==='pipe'||p.role==='pipeline');if(!pipes.length)return 'Pipe-only task but no pipe bot is registered.';const busy=pipes.filter(p=>this.tasks.some(t=>t.attempts?.some(a=>a.profileId===p.id&&activeAttemptStates.has(a.state))));if(busy.length===pipes.length)return 'Pipe bots are all busy; waiting for a free pipe bot.';return 'Pipe-only task: waiting for a pipe bot ('+pipes.map(p=>p.nickname).join(', ')+').';}");
    console.log('waitingReason patched in', file);
  } else console.log('waitingReason already patched or anchor missing in', file);
  fs.writeFileSync(file, c, 'latin1');
}
console.log('done');
