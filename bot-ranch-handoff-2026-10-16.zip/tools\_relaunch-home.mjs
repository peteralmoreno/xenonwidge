import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('homeFolder:', st.homeFolder);
console.log('homeFolders:', st.homeFolders.map(x => x.path).join(' | '));
for (const p of st.profiles) console.log(`${p.nickname}: folder=${p.folder} state=${p.state}`);
// relaunch both against new home (idle, no release -> no paid call)
for (const p of st.profiles) {
  const r = await fetch(base + '/admin/action', { method: 'POST', headers: H, body: JSON.stringify({ id: p.id, action: 'new', confirmed: true }) });
  console.log(`new ${p.nickname}: ${r.status} ${(await r.text()).slice(0, 80)}`);
}
await new Promise(res => setTimeout(res, 28000));
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st2.profiles) console.log(`${p.nickname} now: state=${p.state} status=${p.status}`);