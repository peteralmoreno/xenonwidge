const fs = require('fs');
const ORIG = "['#e58d77','#68bbc3','#ddb55c','#a396ca','#e78fb3','#e8a05b','#a8c966','#65b58e','#729edb','#8585d5','#bbc5cb','#cf7070','#e4dcad','#66d9ce','#d976ed','#a78362']";
const extra = ",'#ff2d2d','#ff4dd8','#2ec4ff','#7cff3f'";
const files = [
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js',
  'C:/source/xenonwidge/sources/omp-bot/desk/app.js',
];
for (const f of files) {
  if (!fs.existsSync(f)) { console.log('skip', f); continue; }
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes("'#ff2d2d'")) { console.log('already 20:', f); continue; }
  if (c.includes(ORIG)) {
    fs.writeFileSync(f, c.replace(ORIG, ORIG.replace(/\]$/, extra + ']')), 'latin1');
    console.log('patched', f);
  } else console.log('ORIG missing', f);
}