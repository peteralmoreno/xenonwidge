import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {spawn,spawnSync} from 'node:child_process';import {pathToFileURL} from 'node:url';
export function handoffEnvironment(env,h){
 if(!h||!path.isAbsolute(h.folder||'')||!path.isAbsolute(h.history||'')||!['resume','task'].includes(h.mode)||!/^[a-f0-9]{64}$/.test(h.token||''))throw Error('Invalid task handoff.');
 fs.mkdirSync(h.history,{recursive:true});const instructions=path.join(h.history,'bot-role.md');fs.writeFileSync(instructions,h.roleInstructions||'');
 return {...env,OMP_BOT_PROJECT:h.folder,OMP_BOT_TASK_WORKSPACE:h.folder,OMP_BOT_SESSION_DIR:h.history,OMP_BOT_OPEN_MODE:h.mode,OMP_BOT_LAUNCH_ID:h.launchId,OMP_BOT_TASK_ID:h.taskId,OMP_BOT_ATTEMPT_ID:h.attemptId,OMP_BOT_DISPATCH_TOKEN:h.token,OMP_BOT_HOME:h.homeFolder,OMP_BOT_ROLE_FILE:instructions,OMP_BOT_ROLE_MODEL:h.preferredModel||'auto',OMP_BOT_READ_ONLY:String(!!h.readOnly)};
}
function killTree(pid){try{spawnSync('taskkill',['/T','/F','/PID',String(pid)],{windowsHide:true,stdio:'ignore'});}catch{}}
// Run one omp session, watching for a `.next.json` handoff while it lives.
// Work-check writes the handoff and calls ctx.shutdown(), which does not
// reliably terminate a non-interactive ranch session; the runner must notice
// the file itself and end the child (and its whole tree) so the loop can
// consume the handoff and respawn with the task environment.
export function runOmpSession(omp,args,env,file){
 return new Promise(resolve=>{
  const child=spawn(omp,args,{cwd:env.OMP_BOT_PROJECT,env,stdio:'inherit',windowsHide:false});
  const watcher=setInterval(()=>{if(fs.existsSync(file)){killTree(child.pid);}},250);
  child.on('exit',(code,signal)=>{clearInterval(watcher);resolve({code:typeof code==='number'?code:(signal?1:1),filePresent:fs.existsSync(file)});});
 });
}
export async function runTerminal(){
 let env={...process.env};const file=env.OMP_BOT_BINDING_FILE+'.next.json';fs.rmSync(file,{force:true});
 const omp=path.join(os.homedir(),'.bun','bin',process.platform==='win32'?'omp.exe':'omp');
 const args=['--extension',env.OMP_BOT_EXTENSION];if(env.OMP_BOT_SESSION_DIR){args.push('--session-dir',env.OMP_BOT_SESSION_DIR);if(env.OMP_BOT_OPEN_MODE==='resume')args.push('--continue');}
 if(process.argv[2]==='--once'){const result=await runOmpSession(omp,args,env,file);process.exitCode=result.code;return;}
 for(;;){
  const result=await runOmpSession(omp,args,env,file);
  if(!result.filePresent)return result.code;
  const next=JSON.parse(fs.readFileSync(file,'utf8'));fs.unlinkSync(file);env=handoffEnvironment(env,next);
 }
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){runTerminal().then(code=>process.exitCode=code).catch(e=>{console.error(e);process.exitCode=1;});}