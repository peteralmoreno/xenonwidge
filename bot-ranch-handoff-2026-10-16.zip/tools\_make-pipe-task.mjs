import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st.profiles) console.log(`${p.nickname}: role=${p.role} auto=${p.autoPickup} state=${p.state}`);
// create pipe-only task
const body = {
  title: 'pipe-catalog-probe', projectFolder: 'C:/bot-home/rooms/piper',
  instructions: 'Trigger a Catalog_Info run for nomore-workspace and babysit it to completion. Report workflow id + status. Do not trigger other runs.',
  acceptanceCriteria: '', reasoningRequest: 'auto', humanReview: true,
  releasedForPickup: false, expectedRevision: st.taskRevision, stickyMode: 'inherit', pipeOnly: true
};
const r = await fetch(base + '/admin/task', { method: 'POST', headers: H, body: JSON.stringify(body) });
const t = await r.json();
console.log('created:', r.status, t.title, 'pipeOnly=' + t.pipeOnly, 'id=' + t.id);
// release it
const rel = { id: t.id, title: t.title, projectFolder: t.projectFolder, instructions: t.instructions, acceptanceCriteria: t.acceptanceCriteria, reasoningRequest: t.reasoningRequest, humanReview: t.humanReview, releasedForPickup: true, expectedRevision: t.revision, stickyMode: t.stickyMode, pipeOnly: true };
const r2 = await fetch(base + '/admin/task', { method: 'POST', headers: H, body: JSON.stringify(rel) });
console.log('released:', r2.status);
// fall through to file for the watcher
fs.writeFileSync('C:/source/xenonwidge/tools/_probe-id.txt', t.id);