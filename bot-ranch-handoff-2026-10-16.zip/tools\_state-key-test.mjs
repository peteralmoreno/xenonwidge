import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// the desk widget polls the PUBLIC /state route with Bearer key. Which key does /state accept?
// /state accepts the COMPANION session key (server 'key' = /admin/key). The widget may be using that instead of control-key!
const k = await (await fetch(base + '/admin/key', { headers: H })).json();
console.log('session key:', k.key.slice(0, 16) + '...');
// Does /state accept the session key?
const r = await fetch(base + '/state', { headers: { Authorization: 'Bearer ' + k.key }, signal: AbortSignal.timeout(3000) });
console.log('/state with session key ->', r.status, (await r.text()).slice(0, 80).replace(/\n/g, ' '));
// Does /state accept the CONTROL key?
const ck = fs.readFileSync('C:/bot-home/control-key.txt', 'utf8').trim();
const r2 = await fetch(base + '/state', { headers: { Authorization: 'Bearer ' + ck }, signal: AbortSignal.timeout(3000) });
console.log('/state with control key ->', r2.status, (await r2.text()).slice(0, 80).replace(/\n/g, ' '));