import fs from 'node:fs';
const d = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
for (const i of [10214, 10239, 10406, 10602]) {
  console.log('---@' + i + '---');
  console.log(d.slice(i - 100, i + 320).replace(/\r/g, ''));
}