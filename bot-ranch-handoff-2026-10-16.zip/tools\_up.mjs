import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
try {
  const st = await (await fetch(base + '/admin/state', { headers: H })).json();
  console.log('companion UP, homeFolder=' + st.homeFolder);
  for (const p of st.profiles) console.log(`${p.nickname}: role=${p.role} auto=${p.autoPickup}`);
} catch (e) { console.log('companion DOWN:', e.message); }