const fs = require('fs');
const files = [
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/app.js',
  'C:/source/xenonwidge/sources/omp-bot-companion/setup/app.js',
];
const ORIG = "'Coral','Cyan','Gold','Violet','Rose','Orange','Lime','Emerald','Blue','Indigo','Silver','Red','Cream','Mint','Orchid','Copper'";
const NEW = ORIG + ",'Hot Red','Magenta','Sky','Neon'";
for (const f of files) {
  let c = fs.readFileSync(f, 'latin1');
  if (c.includes(ORIG) && !c.includes("'Hot Red'")) {
    fs.writeFileSync(f, c.replace(ORIG, NEW), 'latin1');
    console.log('patched', f);
  } else console.log(f, c.includes("'Hot Red'") ? 'already' : 'anchor missing');
}