import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// see where the widget pulls its connection key: /admin/key gives the *session* key; control-key is provisioned. Check both:
const k = await (await fetch(base + '/admin/key', { headers: H })).json();
console.log('/admin/key ->', k.key ? 'key:' + k.key.slice(0, 16) + '... len ' + k.key.length : k);
// provision a fresh control key so the widget can connect (IoT sync)
const ck = await (await fetch(base + '/admin/control-key', { method: 'POST', headers: H })).json();
console.log('control-key provisioned:', ck.controlKey ? ck.controlKey.slice(0, 16) + '...' : ck);
// write it to a file the user can paste (also used as ?key= for control routes)
fs.writeFileSync('C:/bot-home/control-key.txt', ck.controlKey, 'utf8');
console.log('wrote C:/bot-home/control-key.txt');
// now retry control/state with the provisioned key
const r = await fetch(base + '/control/state', { headers: { Authorization: 'Bearer ' + ck.controlKey }, signal: AbortSignal.timeout(3000) });
console.log('/control/state with control key ->', r.status, (await r.text()).slice(0, 100).replace(/\n/g, ' '));