import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st.profiles) {
  console.log(`${p.nickname}: state=${p.state} status=${p.status} label=${p.label} lastSeen=${p.lastSeen ? new Date(p.lastSeen).toISOString().slice(11, 19) : '-'}`);
}
// 1. Rebuild the fixed Terminal-Focus.exe if missing and deploy
const fsx = require ? null : null;