import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key };
// When I fetched /state earlier without Origin, sessions came back. With Origin header, still 200 (CORS).
// BUT: maybe the widget sends a PREFLIGHT due to Authorization header (non-simple). OPTIONS gets 204 WITHOUT CORS headers? reply() sets them for JSON responses; OPTIONS returns 204 null — reply(204,null) sets CORS too (same reply fn). So preflight ok.
// Actually check: reply for OPTIONS passes null body — fine.
// So network is fine. The widget JUST DOESN'T RENDER SESSIONS. This smells like the /state RESPONSE the widget sees has sessions=[] because the widget's fetch resolves base differently: inside iCUE, location.origin is NOT http://127.0.0.1:43822 so base = 'http://127.0.0.1:43822' — correct.
// Unless... the widget is the OLD BUILT file with the OLD base bug? Compare RELEASE desk app base vs installed:
const rel = fs.readFileSync('C:/source/xenonwidge/artifacts/releases/ranch-desk/ranch-desk-0.2.0.icuewidget', 'latin1');
// it's a zip; can't read directly. Use python later. For now inspect installed vs source:
const src = fs.readFileSync('C:/source/xenonwidge/sources/ranch-desk/app.js', 'latin1');
const inst = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js', 'latin1');
console.log('source base:', src.match(/const base = .{0,120}/)?.[0]);
console.log('installed base:', inst.match(/const base = .{0,120}/)?.[0]);
console.log('source slice(0,4):', src.includes('slice(0,4)'));
console.log('installed slice(0,4):', inst.includes('slice(0,4)'));
// Now look at the iCUE widget world: the widget is served to iCUE from the .icuewidget package. iCUE uses a custom scheme origin like https://plugins.corsair.com or blob. fetch('http://127.0.0.1:43822/state') = mixed-content? http from https origin => BLOCKED by Chrome WebView unless --allow-insecure or the host is loopback. Loopback (127.0.0.1) is exempt from mixed content in modern Chrome! But Private Network Access (PNA) preflight (Access-Control-Allow-Private-Network: true present => ok).
// The remaining suspect: iCUE may run the widget in an iframe/puppeteer without network permission unless 'socket' or 'network' permission in manifest.json. Check manifest fields:
const m = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/manifest.json', 'latin1');
console.log('desk manifest keys:', Object.keys(JSON.parse(m)).join(', '));
console.log('permissions in manifest:', /permission/i.test(m) ? m.match(/"((network|socket|url)[^"]*)"/gi) : 'none');
const m2 = fs.readFileSync('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/ui/manifest.json', 'latin1');
console.log('ui manifest permissions:', /permission/i.test(m2) ? m2.match(/"((network|socket|url)[^"]*)"/gi) : 'none');
console.log('ui manifest:', m2.slice(0, 500).replace(/\n/g, ' '));