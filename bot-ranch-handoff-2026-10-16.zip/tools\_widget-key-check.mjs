import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('widgetControlHash set:', !!st.widgetControlHash);
console.log('profiles:', st.profiles.map(p => `${p.nickname}:${p.state}/${p.status}`).join(', '));
console.log('tasks:', st.tasks.filter(t => !t.archived).map(t => `${t.title}[${t.status}]`).join(', '));
// what the desk widget will render: it polls /control/state with the embedded key. The widget build embeds
// its own connection key in the manifest? check the widget manifest
const wm = fs.readFileSync('C:/source/xenonwidge/artifacts/releases/bot-ranch/bot-ranch-0.17.1.icuewidget', 'latin1').slice(0, 400);
console.log('widget head:', wm.replace(/\n/g, ' ').slice(0, 200));