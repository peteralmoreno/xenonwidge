const fs = require('fs');
const root = 'C:/Users/petermo/.omp/agent/skills';
(function walk(d, depth) {
  if (depth > 3) return;
  for (const n of fs.readdirSync(d)) {
    const f = d + '/' + n;
    const s = fs.statSync(f);
    if (s.isDirectory()) { console.log('DIR:', f.slice(root.length + 1)); walk(f, depth + 1); }
    else console.log('  FILE:', f.slice(root.length + 1), s.size);
  }
})(root, 0);