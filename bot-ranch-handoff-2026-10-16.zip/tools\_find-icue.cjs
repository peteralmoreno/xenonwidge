const fs = require('fs');
const root = 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1';
(function walk(d) {
  for (const n of fs.readdirSync(d)) {
    const f = d + '/' + n;
    const s = fs.statSync(f);
    if (s.isDirectory()) { if (!n.startsWith('.')) walk(f); }
    else {
      const c = fs.readFileSync(f, 'latin1');
      if (/icue/i.test(c)) console.log('ICUE-STR:', f, (c.match(/.{0,40}icue.{0,60}/i) || [])[0]?.replace(/\n/g, ' '));
      if (/widget/i.test(n)) console.log('WIDGET-FILE:', f);
    }
  }
})(root);