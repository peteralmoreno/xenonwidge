import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
const p = st.profiles.find(x => x.nickname === 'PM');
if (!p) { console.log('PM profile not found'); process.exit(1); }
console.log('PM:', p.id.slice(0, 8), 'design=' + p.design, 'rev=' + p.revision);
const body2 = { id: p.id, nickname: p.nickname, color: p.color, folder: p.folder, role: p.role, preferredModel: p.preferredModel, readOnly: p.readOnly, autoPickup: p.autoPickup, contextPolicy: p.contextPolicy, personality: p.personality, design: 'pm', instructionsPath: p.instructionsPath, expectedRevision: p.revision };
const r3 = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body2) });
console.log('design->pm:', r3.status, (await r3.text()).slice(0, 160));