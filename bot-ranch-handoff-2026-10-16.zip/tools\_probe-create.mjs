import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
// Hypothesis: new-task insert requires expectedRevision = current board taskRevision.
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('taskRevision:', st.taskRevision, '| tasks:', st.tasks.length);
// 1. create WITHOUT expectedRevision (the skill's current behavior)
let r = await fetch(base + '/admin/task', { method: 'POST', headers: H, body: JSON.stringify({ title: 'PROBE-no-rev', instructions: 'probe' }) });
console.log('no expectedRevision ->', r.status, (await r.text()).slice(0, 90));
// 2. create WITH expectedRevision = current taskRevision
r = await fetch(base + '/admin/task', { method: 'POST', headers: H, body: JSON.stringify({ title: 'PROBE-with-rev', instructions: 'probe', expectedRevision: st.taskRevision }) });
const t = await r.text();
console.log('with expectedRevision ->', r.status, t.slice(0, 120));
if (r.ok) {
  const task = JSON.parse(t);
  console.log('created id:', task.id, 'rev:', task.revision);
  // archive it to keep the board clean
  const r2 = await fetch(base + '/admin/task/archive', { method: 'POST', headers: H, body: JSON.stringify({ id: task.id, expectedRevision: task.revision }) });
  console.log('archive probe ->', r2.status, (await r2.text()).slice(0, 90));
}