const fs = require('fs');
const files = [
  'C:/source/xenonwidge/sources/omp-bot/sprites.js',
  'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/sprites.js',
];
// Verify installed path exists
const installed = 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop/resources/app/sprites.js';
console.log('installed sprites exists:', fs.existsSync(installed));
if (!fs.existsSync(installed)) {
  // search for sprites.js under installed desktop
  const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = d + '/' + f.name; if (f.isDirectory()) walk(p); else if (f.name === 'sprites.js') console.log('FOUND', p); } };
  walk('C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desktop');
}