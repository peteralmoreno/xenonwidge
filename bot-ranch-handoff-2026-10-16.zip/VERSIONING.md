# Bot Ranch Versioning & 0.18 Recipe

How this repo is laid out, how to bump a version, and what a fresh session needs to
turn the current patched state into a new release.

## Layout

```
C:/source/xenonwidge/
  sources/
    omp-bot/          Ranch WIDGET source (ui/: app.js, sprites.js, world.js, appearance.js, widget.css)
    ranch-desk/       Ranch Desk widget source (app.js, appearance.js, widget.css)
    omp-bot-companion/  Companion server source (manager.mjs, terminal-runner.mjs, server.mjs, setup/, …)
    omp-bot-desktop/  Electron desktop (resources/app/*, dock.css) — source of the installed desktop app
  tools/
    build.cjs         release builder: `node tools/build.cjs ranch build`
    build-desktop.cjs desktop staging (called by build.cjs)
    *.cjs / *.mjs / *.ps1  scratch/validation scripts (prefixed _), NOT part of the product
  docs/guides/        guides copied into releases
  artifacts/releases/ build output
    bot-ranch/        bot-ranch-companion-<ver>.zip + bot-ranch-<ver>.icuewidget
    ranch-desk/       ranch-desk-<ver>.icuewidget
  DLs/                unpacked stock release (baseline for diffing)
  PATCHLOG.md         THE list of every local patch (read this first)
```

## Version source of truth

- WIDGET + companion version: `sources/omp-bot/manifest.json` → `"version"`.
  `build.cjs` reads it from there and stamps the release.json + zip names + companion
  `appVersion` (via `omp-bot-desktop/package.json` → `"version"`).
- Desktop app version: `sources/omp-bot-desktop/package.json` → `"version"`.
- Keep BOTH at the same version.
- `DLs/bot-ranch-companion-<ver>/release.json` in the packed tree mirrors it.

## Sync rule (CRITICAL — do not skip)

Every patch in PATCHLOG.md was applied to:
1. `sources/…` (editable tree)
2. installed copy `C:\Users\petermo\AppData\Local\Programs\botRanch\versions\<ver>\`
3. (via a build) the release artifacts in `artifacts/releases/`

When changing a file, apply to ALL copies or the running app and the next release drift.

## How to produce 0.18

1. Read `PATCHLOG.md`; verify each entry still matches the code (files listed exist,
   sentinel strings present). Update PATCHLOG with any changes made since the last entry.
2. Bump version: edit `sources/omp-bot/manifest.json` and
   `sources/omp-bot-desktop/package.json` `"version"` → `"0.18.0"`.
3. Rebuild: `node tools/build.cjs ranch build`
4. Output lands in `artifacts/releases/bot-ranch/` (companion zip + widget) and
   `artifacts/releases/ranch-desk/` (desk widget). Sanity-check the zip:
   - `terminal-runner.mjs` contains `taskkill` (watchdog patch)
   - `manager.mjs` contains `pipeOnly` and `input.color>31` and `'pm'` in design lists
   - `ui/sprites.js` contains `'pm'` and `'tangerine'`
   - `Terminal-Focus.exe` present
   - widget `sprites.js`: 32 color triplets; widget `app.js` (desk): 32 hex
5. Compare against `DLs/bot-ranch-companion-0.17.1/` to confirm only intended files drift.
6. If installing: install to a NEW versioned folder, migrate
   `%LOCALAPPDATA%\OmpBot\ranch.json` carefully (state format is versioned; the manager
   migrates on load with a bump path).

## Behavior constants baked into this machine (do not "fix" them back)

- Companion port: `http://127.0.0.1:43822`; admin key `%LOCALAPPDATA%\OmpBot\admin-key.txt`
  (Bearer). Desktop honors only `127.0.0.1` in iCUE Widget Access.
- Bot home: `C:\bot-home` (NOT next to the app). Rooms under `C:\bot-home\rooms\<nick>`.
- Smoke-runner rule: `taskkill /T /F` is how the terminal runner unblocks omp
  (see PATCHLOG #1) — do not "fix" that back to a graceful shutdown.
- Focus: no-steal default (PATCHLOG #2); `Focus-Terminal.ps1` => `Terminal-Focus.exe`.
- Starting the companion from a shell: `cmd /c start '' "<installed>\desktop\botRanch.exe"`
  works; `Start-Process` is blocked in this harness. The desktop auto-starts the companion
  (Launch-Companion.cmd). To restart the companion alone: `Launch-Companion.cmd`.
- API shorthand: `node tools/_<name>.mjs` scripts exist for state/profile/task admin;
  write new ones prefixed `_` when needed; never inline long bash pipelines.

## What 0.18 should contain (pending changes)

- pm role display name -> "Product Manager" (currently "Project Manager").
- Optional: `git init` `sources/` so diffs are recorded going forward.
- Verify PATCHLOG entries 1-14 against the built artifact before shipping.