const fs = require('fs');
// sync companion sources back to installed copies (app.js/board.js were patched only in installed earlier for setup; sources now patched too — ensure identical)
const pairs = [
  ['C:/source/xenonwidge/sources/omp-bot-companion/setup/app.js', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/app.js'],
  ['C:/source/xenonwidge/sources/omp-bot-companion/setup/board.js', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/setup/board.js'],
  ['C:/source/xenonwidge/sources/omp-bot/sprites.js', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/ui/sprites.js'],
  ['C:/source/xenonwidge/sources/ranch-desk/app.js', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/desk/app.js'],
  ['C:/source/xenonwidge/sources/omp-bot-companion/manager.mjs', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/manager.mjs'],
  ['C:/source/xenonwidge/sources/omp-bot-companion/bot-library.mjs', 'C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1/bot-library.mjs'],
];
for (const [src, dst] of pairs) {
  const a = fs.readFileSync(src, 'latin1'), b = fs.readFileSync(dst, 'latin1');
  console.log(dst.split('/').pop(), a === b ? 'IDENTICAL' : 'DIFFERS');
}
// renderer.js has no source twin; keep as is