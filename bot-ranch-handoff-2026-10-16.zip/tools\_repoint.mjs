import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st.profiles) {
  const body = { id: p.id, nickname: p.nickname, color: p.color, folder: 'C:/bot-home', role: p.role, preferredModel: p.preferredModel, readOnly: p.readOnly, autoPickup: p.autoPickup, contextPolicy: p.contextPolicy, personality: p.personality, design: p.design, instructionsPath: p.instructionsPath, expectedRevision: p.revision };
  const r = await fetch(base + '/admin/profile', { method: 'POST', headers: H, body: JSON.stringify(body) });
  const t = await r.text();
  console.log(`${p.nickname}: ${r.status} ${t.slice(0, 140)}`);
}
// verify
const st2 = await (await fetch(base + '/admin/state', { headers: H })).json();
for (const p of st2.profiles) console.log(`${p.nickname} folder=${p.folder}`);
// tasks projectFolder check
for (const t of st2.tasks) console.log(`task ${t.title} projectFolder=${t.projectFolder}`);