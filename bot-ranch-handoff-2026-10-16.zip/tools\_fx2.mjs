import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execSync } from 'node:child_process';

// 1. Ensure Terminal-Focus.cs/.exe are rebuilt + deployed
const hlp = 'C:/source/xenonwidge/tools/_clm-helpers';
const cs = path.join(hlp, 'Terminal-Focus.cs');
const exe = path.join(hlp, 'Terminal-Focus.exe');
if (!fs.existsSync(exe)) {
  const csc = 'C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe';
  execSync(`"${csc}" /nologo /out:${exe} ${cs}`, { stdio: 'inherit' });
  console.log('compiled Terminal-Focus.exe');
}
for (const d of ['C:/Users/petermo/AppData/Local/Programs/botRanch/versions/0.17.1', 'C:/source/xenonwidge/sources/omp-bot-companion']) {
  fs.copyFileSync(exe, path.join(d, 'Terminal-Focus.exe'));
  console.log('deployed to', d);
}
// 2. Live-test focus on Piper's mintty
const ps = execSync('powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match \'Bot Ranch - Piper\' } | Select-Object -First 1 -ExpandProperty ProcessId"', { encoding: 'utf8' }).trim();
console.log('piper pid:', ps);
const pid = Number(ps);
if (pid) {
  const out = execSync(`${exe} ${pid}`, { encoding: 'utf8' }).trim();
  console.log('focus exit code:', out);
  console.log('focus result:', execSync(`echo done`).toString());
}
// state
const key = fs.readFileSync(path.join(os.homedir(), 'AppData', 'Local', 'OmpBot', 'admin-key.txt'), 'utf8').trim();
const base = 'http://127.0.0.1:43822';
const H = { Authorization: 'Bearer ' + key };
const st = await (await fetch(base + '/admin/state', { headers: H })).json();
console.log('piper state:', st.profiles.find(p => p.nickname === 'Piper')?.state);